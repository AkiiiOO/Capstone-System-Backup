﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace ILAGAN_Management_System
{
    public partial class NewVehicleForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public NewVehicleForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadVehicleTypes();
        }
        private void btn_Upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                picb_Vehicle.Image = Image.FromFile(filePath);
            }
        }
        private void LoadVehicleTypes()
        {
            // Create a DataTable to hold the Vehicle types
            string query = "SELECT VehicleTypeID, VehicleTypeName FROM VehicleType";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                try
                {
                    db.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable dtVehicleTypes = new DataTable();
                        dtVehicleTypes.Load(reader);
                        cmb_VehicleType.DataSource = dtVehicleTypes;
                        cmb_VehicleType.DisplayMember = "VehicleTypeName"; // The field to display
                        cmb_VehicleType.ValueMember = "VehicleTypeID";
                        cmb_VehicleType.SelectedIndex = -1;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error fetching Vehicle Types: " + ex.Message);
                }
                finally
                {
                    db.Close(); // Ensure the database connection is closed
                }
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
             // Check if all fields are filled
            if (cmb_VehicleType.SelectedIndex == -1 || string.IsNullOrEmpty(txt_VehicleName.Text) || string.IsNullOrEmpty(txt_VehiclePrice.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                // Get values from form controls
                int vehicleTypeId = (int)cmb_VehicleType.SelectedValue;
                string vehicleName = txt_VehicleName.Text;
                decimal vehiclePrice = decimal.Parse(txt_VehiclePrice.Text);

                // Convert image to byte array if an image is selected
                byte[] vehicleImage = null;
                if (picb_Vehicle.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        picb_Vehicle.Image.Save(ms, picb_Vehicle.Image.RawFormat);
                        vehicleImage = ms.ToArray();
                    }
                }

                // Prepare the SQL Insert query
                string insertQuery = "INSERT INTO Vehicle (VehicleTypeID, VehicleImage, VehicleName, Price) " +
                                     "VALUES (@VehicleTypeID, @VehicleImage, @VehicleName, @Price)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@VehicleTypeID", vehicleTypeId);
                    command.Parameters.AddWithValue("@VehicleImage", vehicleImage ?? (object)DBNull.Value); // Use DBNull if no image is provided
                    command.Parameters.AddWithValue("@VehicleName", vehicleName);
                    command.Parameters.AddWithValue("@Price", vehiclePrice);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Vehicle inserted successfully.");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Error inserting Vehicle.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace ILAGAN_Management_System
{
    public partial class NewVehicleForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public NewVehicleForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadVehicleTypes();
            LoadVehicleList();
        }
        private void btn_Upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                picb_Vehicle.Image = Image.FromFile(filePath);
            }
        }
        private void LoadVehicleTypes()
        {
            // Create a DataTable to hold the Vehicle types
            string query = "SELECT VehicleTypeID, VehicleTypeName FROM VehicleType";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                try
                {
                    db.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable dtVehicleTypes = new DataTable();
                        dtVehicleTypes.Load(reader);
                        cmb_VehicleType.DataSource = dtVehicleTypes;
                        cmb_VehicleType.DisplayMember = "VehicleTypeName"; // The field to display
                        cmb_VehicleType.ValueMember = "VehicleTypeID";
                        cmb_VehicleType.SelectedIndex = -1;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error fetching Vehicle Types: " + ex.Message);
                }
                finally
                {
                    db.Close(); // Ensure the database connection is closed
                }
            }
        }
        private void LoadVehicleList()
        {
            try
            {
                string query = "SELECT VehicleID, VehicleName, VehicleTypeName, Price, VehicleImage, Vehicle.VehicleTypeID FROM Vehicle " +
                               "JOIN VehicleType ON Vehicle.VehicleTypeID = VehicleType.VehicleTypeID";
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dtVehicleList = new DataTable();
                adapter.Fill(dtVehicleList);

                dgv_VehicleList.DataSource = dtVehicleList;
                dgv_VehicleList.Columns["VehicleTypeID"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading vehicle list: " + ex.Message);
            }
        }
        private void btn_Add_Click(object sender, EventArgs e)
        {
             // Check if all fields are filled
            if (cmb_VehicleType.SelectedIndex == -1 || string.IsNullOrEmpty(txt_VehicleName.Text) || string.IsNullOrEmpty(txt_VehiclePrice.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                // Get values from form controls
                int vehicleTypeId = (int)cmb_VehicleType.SelectedValue;
                string vehicleName = txt_VehicleName.Text;
                decimal vehiclePrice = decimal.Parse(txt_VehiclePrice.Text);

                // Convert image to byte array if an image is selected
                byte[] vehicleImage = null;
                if (picb_Vehicle.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        picb_Vehicle.Image.Save(ms, picb_Vehicle.Image.RawFormat);
                        vehicleImage = ms.ToArray();
                    }
                }

                // Prepare the SQL Insert query
                string insertQuery = "INSERT INTO Vehicle (VehicleTypeID, VehicleImage, VehicleName, Price) " +
                                     "VALUES (@VehicleTypeID, @VehicleImage, @VehicleName, @Price)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@VehicleTypeID", vehicleTypeId);
                    command.Parameters.AddWithValue("@VehicleImage", vehicleImage ?? (object)DBNull.Value); // Use DBNull if no image is provided
                    command.Parameters.AddWithValue("@VehicleName", vehicleName);
                    command.Parameters.AddWithValue("@Price", vehiclePrice);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Vehicle inserted successfully.");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Error inserting Vehicle.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (dgv_VehicleList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a vehicle to update.");
                return;
            }

            if (string.IsNullOrEmpty(txt_VehicleName.Text) || string.IsNullOrEmpty(txt_VehiclePrice.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                int vehicleId = Convert.ToInt32(dgv_VehicleList.SelectedRows[0].Cells["VehicleID"].Value);
                string vehicleName = txt_VehicleName.Text;
                decimal vehiclePrice = decimal.Parse(txt_VehiclePrice.Text);
                int vehicleTypeId = (int)cmb_VehicleType.SelectedValue;

                string updateQuery = "UPDATE Vehicle SET VehicleName = @VehicleName, VehicleTypeID = @VehicleTypeID, " +
                                     "Price = @Price WHERE VehicleID = @VehicleID";

                using (SqlCommand command = new SqlCommand(updateQuery, db))
                {
                    command.Parameters.AddWithValue("@VehicleName", vehicleName);
                    command.Parameters.AddWithValue("@VehicleTypeID", vehicleTypeId);
                    command.Parameters.AddWithValue("@Price", vehiclePrice);
                    command.Parameters.AddWithValue("@VehicleID", vehicleId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Vehicle updated successfully.");
                        LoadVehicleList(); // Refresh the vehicle list
                    }
                    else
                    {
                        MessageBox.Show("Error updating vehicle.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (dgv_VehicleList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a vehicle to delete.");
                return;
            }

            try
            {
                int vehicleId = Convert.ToInt32(dgv_VehicleList.SelectedRows[0].Cells["VehicleID"].Value);

                string deleteQuery = "DELETE FROM Vehicle WHERE VehicleID = @VehicleID";

                using (SqlCommand command = new SqlCommand(deleteQuery, db))
                {
                    command.Parameters.AddWithValue("@VehicleID", vehicleId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Vehicle deleted successfully.");
                        LoadVehicleList(); // Refresh the vehicle list
                    }
                    else
                    {
                        MessageBox.Show("Error deleting vehicle.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dgv_VehicleList_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_VehicleList.Rows[e.RowIndex];
                txt_VehicleName.Text = row.Cells["VehicleName"].Value.ToString();
                txt_VehiclePrice.Text = row.Cells["Price"].Value.ToString();

                if (row.Cells["VehicleTypeID"] != null && row.Cells["VehicleTypeID"].Value != DBNull.Value)
                {
                    cmb_VehicleType.SelectedValue = Convert.ToInt32(row.Cells["VehicleTypeID"].Value);
                }

                if (row.Cells["VehicleImage"].Value != DBNull.Value)
                {
                    byte[] imageData = (byte[])row.Cells["VehicleImage"].Value;
                    using (MemoryStream ms = new MemoryStream(imageData))
                    {
                        picb_Vehicle.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    picb_Vehicle.Image = null;
                }
            }
        }

    }
}

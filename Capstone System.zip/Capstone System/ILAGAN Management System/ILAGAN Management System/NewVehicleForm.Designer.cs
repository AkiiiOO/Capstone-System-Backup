﻿namespace ILAGAN_Management_System
{
    partial class NewVehicleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txt_VehiclePrice = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmb_VehicleType = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_VehicleName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.picb_Vehicle = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dgv_VehicleList = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_Delete = new ILAGAN_Management_System.RoundedButton();
            this.btn_Update = new ILAGAN_Management_System.RoundedButton();
            this.btn_Add = new ILAGAN_Management_System.RoundedButton();
            this.btn_Upload = new ILAGAN_Management_System.RoundedButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_Vehicle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_VehicleList)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(426, 68);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "New Vehicle";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DimGray;
            this.panel3.Location = new System.Drawing.Point(14, 398);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 2);
            this.panel3.TabIndex = 98;
            // 
            // txt_VehiclePrice
            // 
            this.txt_VehiclePrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_VehiclePrice.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_VehiclePrice.Location = new System.Drawing.Point(184, 174);
            this.txt_VehiclePrice.Name = "txt_VehiclePrice";
            this.txt_VehiclePrice.Size = new System.Drawing.Size(215, 25);
            this.txt_VehiclePrice.TabIndex = 96;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 177);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 16);
            this.label2.TabIndex = 95;
            this.label2.Text = "Price:";
            // 
            // cmb_VehicleType
            // 
            this.cmb_VehicleType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_VehicleType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_VehicleType.FormattingEnabled = true;
            this.cmb_VehicleType.Location = new System.Drawing.Point(182, 111);
            this.cmb_VehicleType.Name = "cmb_VehicleType";
            this.cmb_VehicleType.Size = new System.Drawing.Size(233, 26);
            this.cmb_VehicleType.TabIndex = 94;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(16, 116);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 16);
            this.label12.TabIndex = 93;
            this.label12.Text = "Vehicle Type:";
            // 
            // txt_VehicleName
            // 
            this.txt_VehicleName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_VehicleName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_VehicleName.Location = new System.Drawing.Point(184, 143);
            this.txt_VehicleName.Name = "txt_VehicleName";
            this.txt_VehicleName.Size = new System.Drawing.Size(215, 25);
            this.txt_VehicleName.TabIndex = 91;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(16, 146);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 16);
            this.label9.TabIndex = 90;
            this.label9.Text = "Vehicle Name: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SeaGreen;
            this.label6.Location = new System.Drawing.Point(12, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 16);
            this.label6.TabIndex = 89;
            this.label6.Text = "Vehicle Information:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(15, 103);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 2);
            this.panel2.TabIndex = 88;
            // 
            // picb_Vehicle
            // 
            this.picb_Vehicle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.picb_Vehicle.Location = new System.Drawing.Point(184, 205);
            this.picb_Vehicle.Name = "picb_Vehicle";
            this.picb_Vehicle.Size = new System.Drawing.Size(215, 151);
            this.picb_Vehicle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_Vehicle.TabIndex = 92;
            this.picb_Vehicle.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.SeaGreen;
            this.label3.Location = new System.Drawing.Point(16, 379);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 16);
            this.label3.TabIndex = 100;
            this.label3.Text = "Actions:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(161, 463);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(255, 16);
            this.label8.TabIndex = 272;
            this.label8.Text = "Instruction: Double click to select a vehicle\r\n";
            // 
            // dgv_VehicleList
            // 
            this.dgv_VehicleList.AllowUserToAddRows = false;
            this.dgv_VehicleList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_VehicleList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_VehicleList.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_VehicleList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_VehicleList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_VehicleList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_VehicleList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_VehicleList.Location = new System.Drawing.Point(15, 490);
            this.dgv_VehicleList.Name = "dgv_VehicleList";
            this.dgv_VehicleList.ReadOnly = true;
            this.dgv_VehicleList.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_VehicleList.RowHeadersVisible = false;
            this.dgv_VehicleList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_VehicleList.Size = new System.Drawing.Size(401, 126);
            this.dgv_VehicleList.TabIndex = 271;
            this.dgv_VehicleList.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_VehicleList_CellContentDoubleClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SeaGreen;
            this.label4.Location = new System.Drawing.Point(16, 463);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 16);
            this.label4.TabIndex = 270;
            this.label4.Text = "Vehicle List";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DimGray;
            this.panel4.Location = new System.Drawing.Point(15, 482);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(400, 2);
            this.panel4.TabIndex = 269;
            // 
            // btn_Delete
            // 
            this.btn_Delete.BackColor = System.Drawing.Color.Crimson;
            this.btn_Delete.BackgroundColor = System.Drawing.Color.Crimson;
            this.btn_Delete.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Delete.BorderRadius = 5;
            this.btn_Delete.BorderSize = 0;
            this.btn_Delete.FlatAppearance.BorderSize = 0;
            this.btn_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Delete.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete.ForeColor = System.Drawing.Color.White;
            this.btn_Delete.Location = new System.Drawing.Point(345, 418);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(70, 30);
            this.btn_Delete.TabIndex = 102;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.TextColor = System.Drawing.Color.White;
            this.btn_Delete.UseVisualStyleBackColor = false;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Update
            // 
            this.btn_Update.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Update.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Update.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Update.BorderRadius = 5;
            this.btn_Update.BorderSize = 0;
            this.btn_Update.FlatAppearance.BorderSize = 0;
            this.btn_Update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Update.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.ForeColor = System.Drawing.Color.White;
            this.btn_Update.Location = new System.Drawing.Point(185, 418);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(70, 30);
            this.btn_Update.TabIndex = 101;
            this.btn_Update.Text = "Update";
            this.btn_Update.TextColor = System.Drawing.Color.White;
            this.btn_Update.UseVisualStyleBackColor = false;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // btn_Add
            // 
            this.btn_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Add.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Add.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Add.BorderRadius = 5;
            this.btn_Add.BorderSize = 0;
            this.btn_Add.FlatAppearance.BorderSize = 0;
            this.btn_Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Add.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.ForeColor = System.Drawing.Color.White;
            this.btn_Add.Location = new System.Drawing.Point(15, 418);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(70, 30);
            this.btn_Add.TabIndex = 99;
            this.btn_Add.Text = "Add";
            this.btn_Add.TextColor = System.Drawing.Color.White;
            this.btn_Add.UseVisualStyleBackColor = false;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Upload
            // 
            this.btn_Upload.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Upload.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Upload.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Upload.BorderRadius = 5;
            this.btn_Upload.BorderSize = 0;
            this.btn_Upload.FlatAppearance.BorderSize = 0;
            this.btn_Upload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Upload.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Upload.ForeColor = System.Drawing.Color.White;
            this.btn_Upload.Location = new System.Drawing.Point(329, 362);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(70, 30);
            this.btn_Upload.TabIndex = 97;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.TextColor = System.Drawing.Color.White;
            this.btn_Upload.UseVisualStyleBackColor = false;
            this.btn_Upload.Click += new System.EventHandler(this.btn_Upload_Click);
            // 
            // NewVehicleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.ClientSize = new System.Drawing.Size(426, 622);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dgv_VehicleList);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Update);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btn_Upload);
            this.Controls.Add(this.txt_VehiclePrice);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmb_VehicleType);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.picb_Vehicle);
            this.Controls.Add(this.txt_VehicleName);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "NewVehicleForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NewVehicleForm";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_Vehicle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_VehicleList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private RoundedButton btn_Add;
        private System.Windows.Forms.Panel panel3;
        private RoundedButton btn_Upload;
        private System.Windows.Forms.TextBox txt_VehiclePrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmb_VehicleType;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox picb_Vehicle;
        private System.Windows.Forms.TextBox txt_VehicleName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private RoundedButton btn_Delete;
        private RoundedButton btn_Update;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dgv_VehicleList;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
    }
}
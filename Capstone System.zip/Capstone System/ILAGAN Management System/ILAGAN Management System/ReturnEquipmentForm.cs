﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ReturnEquipmentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler ClientAdded;

        private List<DataGridViewRow> selectedRows;
        int serviceRequestID;

        public ReturnEquipmentForm(List<DataGridViewRow> selectedRows)
        {
            InitializeComponent();
            db = y.GetConnection();
            this.selectedRows = selectedRows;
            PopulateRelease();
            LoadEmployees();
        }
        private void PopulateRelease()
        {
            if (selectedRows.Count == 1)
            {
                var row = selectedRows[0];
                if (row.Cells["ServiceRequestID"].Value == null)
                {
                    MessageBox.Show("Invalid Service Request ID.");
                    return;
                }

                serviceRequestID = Convert.ToInt32(row.Cells["ServiceRequestID"].Value);
                LoadReleasedEquipment();
            }
            else
            {
                MessageBox.Show("Please select only one service request.");
            }
        }
        private void LoadReleasedEquipment()
        {
            try
            {
                if (db == null || db.State != ConnectionState.Open)
                {
                    db.Open();
                }

                // Updated Query to fetch equipment based on the selected ServiceRequestID
                string query = @"
                        SELECT 
                            er.EquipmentReleaseID,
                            eq.EquipmentID,
                            eq.EquipmentName, 
                            eq.EquipmentType, 
                            er.Quantity,
                            es.StatusName AS EquipmentStatus, 
                            eq.EquipmentQualityID AS QualityID,
                            eq.EquipmentConditionID AS ConditionID,
                            eq.DamageNote,
                            er.ReleaseDate,
                            er.ReturnDate,
                            (emp1.FirstName + ' ' + emp1.LastName) AS ReleasedByName,
                            (emp2.FirstName + ' ' + emp2.LastName) AS ReturnedByName
                        FROM EquipmentRelease er
                        JOIN Equipment e ON er.EquipmentID = e.EquipmentID
                        JOIN EquipmentStatus es ON er.EquipmentStatusID = es.EquipmentStatusID
                        LEFT JOIN ServiceRequestsPackageEquipments eq ON er.EquipmentID = eq.EquipmentID
                        LEFT JOIN Employees emp1 ON er.ReleasedBy = emp1.EmployeeID
                        LEFT JOIN Employees emp2 ON er.ReturnedBy = emp2.EmployeeID
                        WHERE er.ServiceRequestID = @ServiceRequestID
                        AND eq.ServiceRequestID = @ServiceRequestID";

                SqlCommand cmd = new SqlCommand(query, db);
                cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Bind data to DataGridView
                dgv_EquipmentsReturnDisplay.DataSource = dataTable;

                // Ensure relevant columns are visible and correct
                dgv_EquipmentsReturnDisplay.Columns["SelectColumn"].Visible = true;
                dgv_EquipmentsReturnDisplay.Columns["txt_DamageQuantity"].Visible = true;
                dgv_EquipmentsReturnDisplay.Columns["QualityID"].Visible = false;
                dgv_EquipmentsReturnDisplay.Columns["ConditionID"].Visible = false;
                dgv_EquipmentsReturnDisplay.Columns["DamageNote"].Visible = false;

                // Load dropdowns for Quality and Condition
                DataGridViewComboBoxColumn cmbQuality = new DataGridViewComboBoxColumn
                {
                    Name = "cmb_Quality",
                    HeaderText = "Quality",
                    DataPropertyName = "QualityID"
                };
                cmbQuality.DataSource = GetQualityList(); // Load from EquipmentQuality table
                cmbQuality.DisplayMember = "Quality";
                cmbQuality.ValueMember = "EquipmentQualityID";
                dgv_EquipmentsReturnDisplay.Columns.Add(cmbQuality);

                DataGridViewComboBoxColumn cmbCondition = new DataGridViewComboBoxColumn
                {
                    Name = "cmb_Condition",
                    HeaderText = "Condition",
                    DataPropertyName = "ConditionID"
                };
                cmbCondition.DataSource = GetConditionList(); // Load from EquipmentCondition table
                cmbCondition.DisplayMember = "Condition";
                cmbCondition.ValueMember = "EquipmentConditionID";
                dgv_EquipmentsReturnDisplay.Columns.Add(cmbCondition);

                DataGridViewTextBoxColumn txtDamageNote = new DataGridViewTextBoxColumn
                {
                    Name = "txt_DamageNote",
                    HeaderText = "Damage Note",
                    DataPropertyName = "DamageNote"
                };

                dgv_EquipmentsReturnDisplay.Columns.Add(txtDamageNote);

                // Hide unnecessary columns
                dgv_EquipmentsReturnDisplay.Columns["EquipmentReleaseID"].Visible = false;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentID"].Visible = false;

                dgv_EquipmentsReturnDisplay.Columns["SelectColumn"].DisplayIndex = 0;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentName"].DisplayIndex = 1;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentType"].DisplayIndex = 2;
                dgv_EquipmentsReturnDisplay.Columns["Quantity"].DisplayIndex = 3;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentStatus"].DisplayIndex = 4;
                dgv_EquipmentsReturnDisplay.Columns["cmb_Quality"].DisplayIndex = 5;
                dgv_EquipmentsReturnDisplay.Columns["cmb_Condition"].DisplayIndex = 6;
                dgv_EquipmentsReturnDisplay.Columns["txt_DamageNote"].DisplayIndex = 7;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading equipment: " + ex.Message);
            }
            finally
            {
                if (db != null && db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }
        private DataTable GetQualityList()
        {
            string query = "SELECT EquipmentQualityID, Quality FROM EquipmentQuality";
            SqlDataAdapter adapter = new SqlDataAdapter(query, db);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            return dataTable;
        }

        private DataTable GetConditionList()
        {
            string query = "SELECT EquipmentConditionID, Condition FROM EquipmentCondition";
            SqlDataAdapter adapter = new SqlDataAdapter(query, db);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            return dataTable;
        }

        private void LoadEmployees()
        {
            try
            {
                // Open the database connection
                db.Open();

                // Query to select EmployeeID, FirstName, and LastName from Employees table
                string query = "SELECT EmployeeID, FirstName, LastName FROM Employees";

                SqlCommand cmd = new SqlCommand(query, db);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataTable.Columns.Add("FullName", typeof(string), "FirstName + ' ' + LastName");

                // Bind the data to the ComboBox
                cmb_Employees.DataSource = dataTable;
                cmb_Employees.DisplayMember = "FullName";
                cmb_Employees.ValueMember = "EmployeeID";

                cmb_Employees.SelectedIndex = -1;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading employees: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }

        private void btn_Return_Click(object sender, EventArgs e)
        {
            // Check if an employee is selected
            if (cmb_Employees.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an employee to return the equipment.");
                return;
            }

            // Get the selected employee ID
            int employeeID = Convert.ToInt32(cmb_Employees.SelectedValue);
            DialogResult result = MessageBox.Show(
                "Are you sure you want to return the selected equipment?",
                "Confirm Return",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                return; // Exit the method if the user clicks "No"
            }

            try
            {
                db.Open();

                // Loop through the selected equipment from the DataGridView
                foreach (DataGridViewRow row in dgv_EquipmentsReturnDisplay.Rows)
                {
                    // Check if the row is selected (based on checkbox column or similar mechanism)
                    DataGridViewCheckBoxCell selectCell = row.Cells["SelectColumn"] as DataGridViewCheckBoxCell;
                    if (selectCell != null && Convert.ToBoolean(selectCell.Value))
                    {
                        if (row.Cells["EquipmentName"].Value != null && row.Cells["Quantity"].Value != null)
                        {
                            string equipmentName = row.Cells["EquipmentName"].Value.ToString();
                            int returnedQuantity = Convert.ToInt32(row.Cells["Quantity"].Value);

                            // Get the EquipmentID from the Equipment table based on the Equipment Name
                            string equipmentQuery = "SELECT EquipmentID FROM Equipment WHERE EquipmentName = @EquipmentName";
                            SqlCommand equipmentCmd = new SqlCommand(equipmentQuery, db);
                            equipmentCmd.Parameters.AddWithValue("@EquipmentName", equipmentName);
                            int equipmentID = Convert.ToInt32(equipmentCmd.ExecuteScalar());

                            // Get the quality and condition from the DataGridView ComboBox
                            int qualityID = Convert.ToInt32((row.Cells["cmb_Quality"] as DataGridViewComboBoxCell).Value);
                            int conditionID = Convert.ToInt32((row.Cells["cmb_Condition"] as DataGridViewComboBoxCell).Value);
                            string damageNote = Convert.ToString(row.Cells["txt_DamageNote"].Value);
                            int damageQuantity = 0;

                            // Check if the equipment condition is damaged and handle the damage quantity
                            if (conditionID == 3) // "Damaged" condition
                            {
                                // Input damage quantity for damaged equipment
                                if (row.Cells["txt_DamageQuantity"].Value != null)
                                {
                                    int.TryParse(row.Cells["txt_DamageQuantity"].Value.ToString(), out damageQuantity);
                                }

                                // If damage quantity is greater than 0, insert damaged equipment as a new record
                                if (damageQuantity > 0)
                                {
                                    // Insert the damaged equipment as a new record
                                    string insertDamageQuery = @"
                    INSERT INTO Equipment (EquipmentName, EquipmentType, EquipmentQualityID, EquipmentConditionID, Quantity, DamageNote)
                    VALUES (@EquipmentName, @EquipmentType, @QualityID, @ConditionID, @DamageQuantity, @DamageNote)";
                                    SqlCommand insertDamageCmd = new SqlCommand(insertDamageQuery, db);
                                    insertDamageCmd.Parameters.AddWithValue("@EquipmentName", equipmentName);
                                    insertDamageCmd.Parameters.AddWithValue("@EquipmentType", row.Cells["EquipmentType"].Value);
                                    insertDamageCmd.Parameters.AddWithValue("@QualityID", qualityID);
                                    insertDamageCmd.Parameters.AddWithValue("@ConditionID", conditionID);
                                    insertDamageCmd.Parameters.AddWithValue("@DamageQuantity", damageQuantity);
                                    insertDamageCmd.Parameters.AddWithValue("@DamageNote", damageNote);
                                    insertDamageCmd.ExecuteNonQuery();

                                    // Update the remaining quantity in the existing equipment record
                                    returnedQuantity -= damageQuantity;
                                }
                                else
                                {
                                    MessageBox.Show("Invalid damage quantity entered.");
                                    return;
                                }
                            }

                            // Now update only the remaining undamaged equipment (i.e., `returnedQuantity`)
                            if (returnedQuantity > 0)
                            {
                                string updateReturnQuery = @"
                    UPDATE Equipment
                    SET Quantity = Quantity + @ReturnedQuantity
                    WHERE EquipmentID = @EquipmentID";
                                SqlCommand updateReturnCmd = new SqlCommand(updateReturnQuery, db);
                                updateReturnCmd.Parameters.AddWithValue("@ReturnedQuantity", returnedQuantity);
                                updateReturnCmd.Parameters.AddWithValue("@EquipmentID", equipmentID);
                                updateReturnCmd.ExecuteNonQuery();
                            }

                            // Now update the status in EquipmentRelease table to mark as returned
                            string updateStatusQuery = @"
                UPDATE EquipmentRelease
                SET EquipmentStatusID = 4,  -- Update status to 'Returned'
                    ReturnDate = GETDATE(),
                    ReturnedBy = @ReturnedBy
                WHERE EquipmentID = @EquipmentID AND ServiceRequestID = @ServiceRequestID";
                            SqlCommand updateStatusCmd = new SqlCommand(updateStatusQuery, db);
                            updateStatusCmd.Parameters.AddWithValue("@ReturnedBy", employeeID);
                            updateStatusCmd.Parameters.AddWithValue("@EquipmentID", equipmentID);
                            updateStatusCmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);
                            updateStatusCmd.ExecuteNonQuery();
                        }
                    }
                }

                MessageBox.Show("Equipment has been successfully returned.");
                ClientAdded.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error returning equipment: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }
    }
}

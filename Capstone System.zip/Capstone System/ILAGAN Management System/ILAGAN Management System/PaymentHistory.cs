﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class PaymentHistory : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public PaymentHistory()
        {
            InitializeComponent();
            db = y.GetConnection();
            customizeDesign();
            DisplayPaymentHistory();
        }
        private void customizeDesign()
        {
            panelUserSubmenu.Visible = false;
            panelServiceSubMenu.Visible = false;
            panelTransactionSubMenu.Visible = false;
            panelInventorySubMenu.Visible = false;
            panelReportsSubMenu.Visible = false;
            panelSettingsSubMenu.Visible = false;
        }

        private void hideSubMenu()
        {
            //user
            if (panelUserSubmenu.Visible == true)
                panelUserSubmenu.Visible = false;
            //service
            if (panelServiceSubMenu.Visible == true)
                panelServiceSubMenu.Visible = false;
            //transaction
            if (panelTransactionSubMenu.Visible == true)
                panelTransactionSubMenu.Visible = false;
            //inventory
            if (panelInventorySubMenu.Visible == true)
                panelInventorySubMenu.Visible = false;
            //reports
            if (panelReportsSubMenu.Visible == true)
                panelReportsSubMenu.Visible = false;
            //setting
            if (panelSettingsSubMenu.Visible == true)
                panelSettingsSubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        //Home Nav
        private void btn_Home_Click(object sender, EventArgs e)
        {
            Home form2 = new Home();
            form2.Show();
            this.Hide();
        }

        //UserSubMenu
        private void btn_User_Click(object sender, EventArgs e)
        {
            showSubMenu(panelUserSubmenu);
        }
        //TheSubMenus
        private void btn_AddUser_Click(object sender, EventArgs e)
        {
            AddUser form1 = new AddUser();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_UserLog_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_Permission_Click(object sender, EventArgs e)
        {
            Permission form1 = new Permission();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }

        //ServiceSubMenu
        private void btn_Service_Click(object sender, EventArgs e)
        {
            showSubMenu(panelServiceSubMenu);
        }
        //TheSubMenus
        private void btn_AddClient_Click(object sender, EventArgs e)
        {
            AddClient form3 = new AddClient();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ServiceRequest_Click(object sender, EventArgs e)
        {
            ServiceRequest form3 = new ServiceRequest();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Package_Click(object sender, EventArgs e)
        {
            CreatePackage form2 = new CreatePackage();
            form2.Show();
            this.Hide();
            hideSubMenu();
        }


        //TransactionSubMenu
        private void btn_Transaction_Click(object sender, EventArgs e)
        {
            showSubMenu(panelTransactionSubMenu);
        }
        //TheSubMenus
        private void btn_Payment_Click(object sender, EventArgs e)
        {
            Payment form3 = new Payment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_InstallmentPayment_Click_1(object sender, EventArgs e)
        {
            InstallmentPayment form3 = new InstallmentPayment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        //InventorySubMenus
        private void btn_Inventory_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelInventorySubMenu);
        }
        private void btn_AddEquipment_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        //ReportsSubMenus
        private void btn_Reports_Click(object sender, EventArgs e)
        {
            showSubMenu(panelReportsSubMenu);
        }
        private void btn_ServiceHistory_Click(object sender, EventArgs e)
        {
            ServiceHistory form3 = new ServiceHistory();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_PaymentHistory_Click(object sender, EventArgs e)
        {
            PaymentHistory form3 = new PaymentHistory();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_EquipmentReleaseLog_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_Inventory_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_Sales_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_EquipmentNarrative_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        //SettingsSubMenus
        private void btn_Settings_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSettingsSubMenu);
        }
        private void btn_EmployeeList_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_AccountDetails_Click(object sender, EventArgs e)
        {
            AccountDetails form3 = new AccountDetails();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ChangePassword_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //ask the user if they want to logout
            DialogResult respond = MessageBox.Show("Are you sure you want to log out?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If user clicks Yes log out and go back to login form
            if (respond == DialogResult.Yes)
            {
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }
        private void DisplayPaymentHistory()
        {
            string query = @"
        SELECT p.PaymentID, p.ClientName, p.TotalPrice, p.DiscountApplied, p.DiscountAmount, 
               p.FinalPrice, p.PaymentOption, p.RemainingBalance, ps.PaymentStatusName AS PaymentStatus
        FROM Payments p
        LEFT JOIN Installments i ON p.PaymentID = i.PaymentID
        LEFT JOIN PaymentStatus ps ON p.PaymentStatusID = ps.PaymentStatusID
        WHERE p.PaymentStatusID = 3 
              AND (i.PaymentID IS NULL OR i.PaymentStatusID = 3)
        GROUP BY p.PaymentID, p.ClientName, p.TotalPrice, p.DiscountApplied, 
                 p.DiscountAmount, p.FinalPrice, p.PaymentOption, 
                 p.RemainingBalance, ps.PaymentStatusName
        HAVING COUNT(i.InstallmentID) = COUNT(CASE WHEN i.PaymentStatusID = 3 THEN 1 END) 
               OR COUNT(i.InstallmentID) = 0";


            DataTable paymentHistoryData = new DataTable();

            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                try
                {
                    db.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(paymentHistoryData);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving payment history: " + ex.Message);
                }
                finally
                {
                    db.Close();
                }
            }

            // Bind the data to a DataGridView control
            dgv_PaymentHistory.DataSource = paymentHistoryData;

            // Optionally, set column headers
            dgv_PaymentHistory.Columns["PaymentID"].HeaderText = "Payment ID";
            dgv_PaymentHistory.Columns["ClientName"].HeaderText = "Client Name";
            dgv_PaymentHistory.Columns["TotalPrice"].HeaderText = "Total Price";
            dgv_PaymentHistory.Columns["DiscountApplied"].HeaderText = "Discount Applied";
            dgv_PaymentHistory.Columns["DiscountAmount"].HeaderText = "Discount Amount";
            dgv_PaymentHistory.Columns["FinalPrice"].HeaderText = "Final Price";
            dgv_PaymentHistory.Columns["PaymentOption"].HeaderText = "Payment Option";
            dgv_PaymentHistory.Columns["RemainingBalance"].HeaderText = "Remaining Balance";
            dgv_PaymentHistory.Columns["PaymentStatus"].HeaderText = "Payment Status";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ManageUserStatus : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler UpdateStatus;

        public ManageUserStatus()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadStatusOptions();
        }

        private void LoadStatusOptions()
        {
            try
            {
                db.Open();
                cmb_Status.Items.Clear();
                string query = "SELECT StatusName FROM UserStatus";
                SqlCommand command = new SqlCommand(query, db);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    cmb_Status.Items.Add(reader["StatusName"].ToString());
                }

                cmb_Status.DropDownStyle = ComboBoxStyle.DropDownList;
                cmb_Status.FormattingEnabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading statuses: " + ex.Message);
            }
            finally
            {
                if (db.State == System.Data.ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }

        private void btn_UpdateStatus_Click(object sender, EventArgs e)
        {
            int currentUserId = CurrentUser.UserID;
            string usernameToUpdate = txtUsername.Text;
            string selectedStatus = cmb_Status.Text;

            // Check if the user trying to update is online
            if (currentUserId == GetUserIdByUsername(usernameToUpdate))
            {
                MessageBox.Show("You cannot deactivate yourself while online.");
                return;
            }

            // Check if at least one admin remains active
            if (selectedStatus.ToLower() == "inactive" && !IsAdminRemainingActive())
            {
                MessageBox.Show("There must be at least one admin online.");
                return;
            }

            try
            {
                db.Open();
                string query = "UPDATE Users SET StatusID = (SELECT StatusID FROM UserStatus WHERE StatusName = @Status) WHERE Username = @Username";
                SqlCommand command = new SqlCommand(query, db);

                command.Parameters.AddWithValue("@Status", selectedStatus);
                command.Parameters.AddWithValue("@Username", usernameToUpdate);

                int result = command.ExecuteNonQuery();
                if (result > 0)
                {
                    MessageBox.Show("User status updated successfully.");
                    UpdateStatus.Invoke(this, EventArgs.Empty);
                }
                else
                {
                    MessageBox.Show("User not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while updating the status: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }
        private int GetUserIdByUsername(string username)
        {
            int userId = 0;
            try
            {
                db.Open();
                string query = "SELECT UserID FROM Users WHERE Username = @Username";
                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@Username", username);

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    userId = Convert.ToInt32(reader["UserID"]);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving user ID: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
            return userId;
        }
        private bool IsAdminRemainingActive()
        {
            int activeAdmins = 0;
            try
            {
                db.Open();
                string query = "SELECT COUNT(*) FROM Users WHERE Role = 'Admin' AND StatusID = (SELECT StatusID FROM UserStatus WHERE StatusName = 'Active')";
                SqlCommand command = new SqlCommand(query, db);
                activeAdmins = Convert.ToInt32(command.ExecuteScalar());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking active admins: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
            return activeAdmins > 0;
        }

    }
}

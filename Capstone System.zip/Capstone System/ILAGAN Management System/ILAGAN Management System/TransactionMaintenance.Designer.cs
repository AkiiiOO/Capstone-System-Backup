﻿namespace ILAGAN_Management_System
{
    partial class TransactionMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLogout = new ILAGAN_Management_System.RoundedButton();
            this.SystemNamelbl = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txt_PaymentInterval = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_DeletePlan = new ILAGAN_Management_System.RoundedButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_EditPlan = new ILAGAN_Management_System.RoundedButton();
            this.btn_Delete = new ILAGAN_Management_System.RoundedButton();
            this.btn_Addplan = new ILAGAN_Management_System.RoundedButton();
            this.btn_Update = new ILAGAN_Management_System.RoundedButton();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_Add = new ILAGAN_Management_System.RoundedButton();
            this.txt_PlanName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_DiscountName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_NumberOfPayments = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_DiscountRate = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgv_PlanList = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.dgv_DiscountList = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelSettingsSubMenu = new System.Windows.Forms.Panel();
            this.btn_TransactionMaintenance = new ILAGAN_Management_System.RoundedButton();
            this.btn_ServiceFileMaintenance = new ILAGAN_Management_System.RoundedButton();
            this.btn_Package = new ILAGAN_Management_System.RoundedButton();
            this.btn_EmployeeList = new ILAGAN_Management_System.RoundedButton();
            this.btn_AddEquipment = new ILAGAN_Management_System.RoundedButton();
            this.btn_AddClient = new ILAGAN_Management_System.RoundedButton();
            this.btn_AddUser = new ILAGAN_Management_System.RoundedButton();
            this.btn_AccountDetails = new ILAGAN_Management_System.RoundedButton();
            this.btn_Settings = new ILAGAN_Management_System.RoundedButton();
            this.panelReportsSubMenu = new System.Windows.Forms.Panel();
            this.btn_Sales = new ILAGAN_Management_System.RoundedButton();
            this.btn_InventoryMasterList = new ILAGAN_Management_System.RoundedButton();
            this.btn_EquipmentReleaseLog = new ILAGAN_Management_System.RoundedButton();
            this.btn_ServiceHistory = new ILAGAN_Management_System.RoundedButton();
            this.btn_Reports = new ILAGAN_Management_System.RoundedButton();
            this.panelInventorySubMenu = new System.Windows.Forms.Panel();
            this.btn_ReturnEquipment = new ILAGAN_Management_System.RoundedButton();
            this.btn_Release = new ILAGAN_Management_System.RoundedButton();
            this.btn_Inventory = new ILAGAN_Management_System.RoundedButton();
            this.panelTransactionSubMenu = new System.Windows.Forms.Panel();
            this.btn_InstallmentPayment = new ILAGAN_Management_System.RoundedButton();
            this.btn_Payment = new ILAGAN_Management_System.RoundedButton();
            this.btn_Transaction = new ILAGAN_Management_System.RoundedButton();
            this.panelServiceSubMenu = new System.Windows.Forms.Panel();
            this.btn_ServiceRequest = new ILAGAN_Management_System.RoundedButton();
            this.btn_Service = new ILAGAN_Management_System.RoundedButton();
            this.panelUserSubmenu = new System.Windows.Forms.Panel();
            this.btn_UserLog = new ILAGAN_Management_System.RoundedButton();
            this.btn_User = new ILAGAN_Management_System.RoundedButton();
            this.btn_Home = new ILAGAN_Management_System.RoundedButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PlanList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DiscountList)).BeginInit();
            this.panel2.SuspendLayout();
            this.panelSettingsSubMenu.SuspendLayout();
            this.panelReportsSubMenu.SuspendLayout();
            this.panelInventorySubMenu.SuspendLayout();
            this.panelTransactionSubMenu.SuspendLayout();
            this.panelServiceSubMenu.SuspendLayout();
            this.panelUserSubmenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.SystemNamelbl);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.panel1.Size = new System.Drawing.Size(984, 100);
            this.panel1.TabIndex = 2;
            // 
            // btnLogout
            // 
            this.btnLogout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnLogout.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnLogout.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btnLogout.BorderRadius = 5;
            this.btnLogout.BorderSize = 0;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Location = new System.Drawing.Point(877, 40);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(80, 30);
            this.btnLogout.TabIndex = 8;
            this.btnLogout.Text = "Log out";
            this.btnLogout.TextColor = System.Drawing.Color.White;
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // SystemNamelbl
            // 
            this.SystemNamelbl.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SystemNamelbl.ForeColor = System.Drawing.Color.Black;
            this.SystemNamelbl.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.SystemNamelbl.Location = new System.Drawing.Point(111, 31);
            this.SystemNamelbl.Name = "SystemNamelbl";
            this.SystemNamelbl.Size = new System.Drawing.Size(209, 47);
            this.SystemNamelbl.TabIndex = 4;
            this.SystemNamelbl.Text = "Ilagan Funeral Home Management System";
            this.SystemNamelbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(38, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(67, 67);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.txt_PaymentInterval);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.btn_DeletePlan);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.btn_EditPlan);
            this.panel3.Controls.Add(this.btn_Delete);
            this.panel3.Controls.Add(this.btn_Addplan);
            this.panel3.Controls.Add(this.btn_Update);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.btn_Add);
            this.panel3.Controls.Add(this.txt_PlanName);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.txt_DiscountName);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.txt_NumberOfPayments);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.txt_DiscountRate);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.dgv_PlanList);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.dgv_DiscountList);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Location = new System.Drawing.Point(238, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(748, 564);
            this.panel3.TabIndex = 8;
            // 
            // txt_PaymentInterval
            // 
            this.txt_PaymentInterval.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_PaymentInterval.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PaymentInterval.Location = new System.Drawing.Point(299, 360);
            this.txt_PaymentInterval.Name = "txt_PaymentInterval";
            this.txt_PaymentInterval.Size = new System.Drawing.Size(198, 25);
            this.txt_PaymentInterval.TabIndex = 325;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(127, 363);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(108, 16);
            this.label13.TabIndex = 324;
            this.label13.Text = "Payment Interval:";
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel7.BackColor = System.Drawing.Color.DimGray;
            this.panel7.Location = new System.Drawing.Point(129, 464);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(500, 2);
            this.panel7.TabIndex = 321;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.BackColor = System.Drawing.Color.DimGray;
            this.panel6.Location = new System.Drawing.Point(128, 165);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(500, 2);
            this.panel6.TabIndex = 307;
            // 
            // panel8
            // 
            this.panel8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel8.BackColor = System.Drawing.Color.DimGray;
            this.panel8.Location = new System.Drawing.Point(129, 295);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(500, 2);
            this.panel8.TabIndex = 322;
            // 
            // panel9
            // 
            this.panel9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel9.BackColor = System.Drawing.Color.DimGray;
            this.panel9.Location = new System.Drawing.Point(133, 406);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(500, 2);
            this.panel9.TabIndex = 320;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.DimGray;
            this.panel5.Location = new System.Drawing.Point(129, 23);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(500, 2);
            this.panel5.TabIndex = 307;
            // 
            // btn_DeletePlan
            // 
            this.btn_DeletePlan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_DeletePlan.BackColor = System.Drawing.Color.Crimson;
            this.btn_DeletePlan.BackgroundColor = System.Drawing.Color.Crimson;
            this.btn_DeletePlan.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_DeletePlan.BorderRadius = 5;
            this.btn_DeletePlan.BorderSize = 0;
            this.btn_DeletePlan.FlatAppearance.BorderSize = 0;
            this.btn_DeletePlan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DeletePlan.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DeletePlan.ForeColor = System.Drawing.Color.White;
            this.btn_DeletePlan.Location = new System.Drawing.Point(559, 412);
            this.btn_DeletePlan.Name = "btn_DeletePlan";
            this.btn_DeletePlan.Size = new System.Drawing.Size(70, 30);
            this.btn_DeletePlan.TabIndex = 319;
            this.btn_DeletePlan.Text = "Delete";
            this.btn_DeletePlan.TextColor = System.Drawing.Color.White;
            this.btn_DeletePlan.UseVisualStyleBackColor = false;
            this.btn_DeletePlan.Click += new System.EventHandler(this.btn_DeletePlan_Click);
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.DimGray;
            this.panel4.Location = new System.Drawing.Point(129, 108);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(500, 2);
            this.panel4.TabIndex = 306;
            // 
            // btn_EditPlan
            // 
            this.btn_EditPlan.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btn_EditPlan.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_EditPlan.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_EditPlan.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_EditPlan.BorderRadius = 5;
            this.btn_EditPlan.BorderSize = 0;
            this.btn_EditPlan.FlatAppearance.BorderSize = 0;
            this.btn_EditPlan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EditPlan.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EditPlan.ForeColor = System.Drawing.Color.White;
            this.btn_EditPlan.Location = new System.Drawing.Point(353, 412);
            this.btn_EditPlan.Name = "btn_EditPlan";
            this.btn_EditPlan.Size = new System.Drawing.Size(70, 30);
            this.btn_EditPlan.TabIndex = 318;
            this.btn_EditPlan.Text = "Update";
            this.btn_EditPlan.TextColor = System.Drawing.Color.White;
            this.btn_EditPlan.UseVisualStyleBackColor = false;
            this.btn_EditPlan.Click += new System.EventHandler(this.btn_EditPlan_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Delete.BackColor = System.Drawing.Color.Crimson;
            this.btn_Delete.BackgroundColor = System.Drawing.Color.Crimson;
            this.btn_Delete.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Delete.BorderRadius = 5;
            this.btn_Delete.BorderSize = 0;
            this.btn_Delete.FlatAppearance.BorderSize = 0;
            this.btn_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Delete.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete.ForeColor = System.Drawing.Color.White;
            this.btn_Delete.Location = new System.Drawing.Point(559, 114);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(70, 30);
            this.btn_Delete.TabIndex = 305;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.TextColor = System.Drawing.Color.White;
            this.btn_Delete.UseVisualStyleBackColor = false;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Addplan
            // 
            this.btn_Addplan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Addplan.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Addplan.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Addplan.BorderRadius = 5;
            this.btn_Addplan.BorderSize = 0;
            this.btn_Addplan.FlatAppearance.BorderSize = 0;
            this.btn_Addplan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Addplan.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Addplan.ForeColor = System.Drawing.Color.White;
            this.btn_Addplan.Location = new System.Drawing.Point(129, 412);
            this.btn_Addplan.Name = "btn_Addplan";
            this.btn_Addplan.Size = new System.Drawing.Size(70, 30);
            this.btn_Addplan.TabIndex = 317;
            this.btn_Addplan.Text = "Add";
            this.btn_Addplan.TextColor = System.Drawing.Color.White;
            this.btn_Addplan.UseVisualStyleBackColor = false;
            this.btn_Addplan.Click += new System.EventHandler(this.btn_Addplan_Click);
            // 
            // btn_Update
            // 
            this.btn_Update.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btn_Update.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Update.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Update.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Update.BorderRadius = 5;
            this.btn_Update.BorderSize = 0;
            this.btn_Update.FlatAppearance.BorderSize = 0;
            this.btn_Update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Update.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.ForeColor = System.Drawing.Color.White;
            this.btn_Update.Location = new System.Drawing.Point(353, 114);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(70, 30);
            this.btn_Update.TabIndex = 304;
            this.btn_Update.Text = "Update";
            this.btn_Update.TextColor = System.Drawing.Color.White;
            this.btn_Update.UseVisualStyleBackColor = false;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(125, 464);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 16);
            this.label2.TabIndex = 316;
            this.label2.Text = "Instruction: Double click to select";
            // 
            // btn_Add
            // 
            this.btn_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Add.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Add.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Add.BorderRadius = 5;
            this.btn_Add.BorderSize = 0;
            this.btn_Add.FlatAppearance.BorderSize = 0;
            this.btn_Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Add.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.ForeColor = System.Drawing.Color.White;
            this.btn_Add.Location = new System.Drawing.Point(125, 114);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(70, 30);
            this.btn_Add.TabIndex = 303;
            this.btn_Add.Text = "Add";
            this.btn_Add.TextColor = System.Drawing.Color.White;
            this.btn_Add.UseVisualStyleBackColor = false;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // txt_PlanName
            // 
            this.txt_PlanName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_PlanName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PlanName.Location = new System.Drawing.Point(299, 303);
            this.txt_PlanName.Name = "txt_PlanName";
            this.txt_PlanName.Size = new System.Drawing.Size(197, 25);
            this.txt_PlanName.TabIndex = 313;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(128, 170);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(201, 16);
            this.label5.TabIndex = 302;
            this.label5.Text = "Instruction: Double click to select";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.SeaGreen;
            this.label7.Location = new System.Drawing.Point(127, 276);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(188, 16);
            this.label7.TabIndex = 308;
            this.label7.Text = "Installment Plan Information";
            // 
            // txt_DiscountName
            // 
            this.txt_DiscountName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DiscountName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DiscountName.Location = new System.Drawing.Point(298, 31);
            this.txt_DiscountName.Name = "txt_DiscountName";
            this.txt_DiscountName.Size = new System.Drawing.Size(197, 25);
            this.txt_DiscountName.TabIndex = 296;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.SeaGreen;
            this.label8.Location = new System.Drawing.Point(130, 385);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 16);
            this.label8.TabIndex = 309;
            this.label8.Text = "Actions:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SeaGreen;
            this.label6.Location = new System.Drawing.Point(124, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 16);
            this.label6.TabIndex = 288;
            this.label6.Text = "Discount Information";
            // 
            // txt_NumberOfPayments
            // 
            this.txt_NumberOfPayments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_NumberOfPayments.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NumberOfPayments.Location = new System.Drawing.Point(299, 331);
            this.txt_NumberOfPayments.Name = "txt_NumberOfPayments";
            this.txt_NumberOfPayments.Size = new System.Drawing.Size(198, 25);
            this.txt_NumberOfPayments.TabIndex = 315;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.SeaGreen;
            this.label3.Location = new System.Drawing.Point(126, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 16);
            this.label3.TabIndex = 292;
            this.label3.Text = "Actions:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(130, 334);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(134, 16);
            this.label10.TabIndex = 314;
            this.label10.Text = "Number of Payments:";
            // 
            // txt_DiscountRate
            // 
            this.txt_DiscountRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DiscountRate.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DiscountRate.Location = new System.Drawing.Point(298, 64);
            this.txt_DiscountRate.Name = "txt_DiscountRate";
            this.txt_DiscountRate.Size = new System.Drawing.Size(198, 25);
            this.txt_DiscountRate.TabIndex = 298;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.SeaGreen;
            this.label11.Location = new System.Drawing.Point(126, 445);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(141, 16);
            this.label11.TabIndex = 310;
            this.label11.Text = "Installment Plan List:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(130, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 16);
            this.label1.TabIndex = 297;
            this.label1.Text = "Discount Rate:";
            // 
            // dgv_PlanList
            // 
            this.dgv_PlanList.AllowUserToAddRows = false;
            this.dgv_PlanList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_PlanList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_PlanList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_PlanList.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_PlanList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_PlanList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_PlanList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_PlanList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_PlanList.Location = new System.Drawing.Point(128, 483);
            this.dgv_PlanList.Name = "dgv_PlanList";
            this.dgv_PlanList.ReadOnly = true;
            this.dgv_PlanList.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_PlanList.RowHeadersVisible = false;
            this.dgv_PlanList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_PlanList.Size = new System.Drawing.Size(500, 67);
            this.dgv_PlanList.TabIndex = 311;
            this.dgv_PlanList.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_PlanList_CellContentDoubleClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SeaGreen;
            this.label4.Location = new System.Drawing.Point(126, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 16);
            this.label4.TabIndex = 293;
            this.label4.Text = "Discount List:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(130, 306);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 16);
            this.label12.TabIndex = 312;
            this.label12.Text = "Plan Name:";
            // 
            // dgv_DiscountList
            // 
            this.dgv_DiscountList.AllowUserToAddRows = false;
            this.dgv_DiscountList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_DiscountList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_DiscountList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_DiscountList.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_DiscountList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_DiscountList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_DiscountList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_DiscountList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_DiscountList.Location = new System.Drawing.Point(131, 189);
            this.dgv_DiscountList.Name = "dgv_DiscountList";
            this.dgv_DiscountList.ReadOnly = true;
            this.dgv_DiscountList.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_DiscountList.RowHeadersVisible = false;
            this.dgv_DiscountList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_DiscountList.Size = new System.Drawing.Size(497, 79);
            this.dgv_DiscountList.TabIndex = 294;
            this.dgv_DiscountList.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_DiscountList_CellContentDoubleClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(130, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 16);
            this.label9.TabIndex = 295;
            this.label9.Text = "Discount Name:";
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(210)))), ((int)(((byte)(159)))));
            this.panel2.Controls.Add(this.panelSettingsSubMenu);
            this.panel2.Controls.Add(this.btn_Settings);
            this.panel2.Controls.Add(this.panelReportsSubMenu);
            this.panel2.Controls.Add(this.btn_Reports);
            this.panel2.Controls.Add(this.panelInventorySubMenu);
            this.panel2.Controls.Add(this.btn_Inventory);
            this.panel2.Controls.Add(this.panelTransactionSubMenu);
            this.panel2.Controls.Add(this.btn_Transaction);
            this.panel2.Controls.Add(this.panelServiceSubMenu);
            this.panel2.Controls.Add(this.btn_Service);
            this.panel2.Controls.Add(this.panelUserSubmenu);
            this.panel2.Controls.Add(this.btn_User);
            this.panel2.Controls.Add(this.btn_Home);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(240, 562);
            this.panel2.TabIndex = 9;
            // 
            // panelSettingsSubMenu
            // 
            this.panelSettingsSubMenu.AutoSize = true;
            this.panelSettingsSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelSettingsSubMenu.Controls.Add(this.btn_TransactionMaintenance);
            this.panelSettingsSubMenu.Controls.Add(this.btn_ServiceFileMaintenance);
            this.panelSettingsSubMenu.Controls.Add(this.btn_Package);
            this.panelSettingsSubMenu.Controls.Add(this.btn_EmployeeList);
            this.panelSettingsSubMenu.Controls.Add(this.btn_AddEquipment);
            this.panelSettingsSubMenu.Controls.Add(this.btn_AddClient);
            this.panelSettingsSubMenu.Controls.Add(this.btn_AddUser);
            this.panelSettingsSubMenu.Controls.Add(this.btn_AccountDetails);
            this.panelSettingsSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSettingsSubMenu.ForeColor = System.Drawing.Color.Gray;
            this.panelSettingsSubMenu.Location = new System.Drawing.Point(0, 595);
            this.panelSettingsSubMenu.Name = "panelSettingsSubMenu";
            this.panelSettingsSubMenu.Size = new System.Drawing.Size(223, 280);
            this.panelSettingsSubMenu.TabIndex = 29;
            // 
            // btn_TransactionMaintenance
            // 
            this.btn_TransactionMaintenance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_TransactionMaintenance.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_TransactionMaintenance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_TransactionMaintenance.BorderRadius = 0;
            this.btn_TransactionMaintenance.BorderSize = 0;
            this.btn_TransactionMaintenance.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_TransactionMaintenance.FlatAppearance.BorderSize = 0;
            this.btn_TransactionMaintenance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_TransactionMaintenance.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TransactionMaintenance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_TransactionMaintenance.Location = new System.Drawing.Point(0, 245);
            this.btn_TransactionMaintenance.Name = "btn_TransactionMaintenance";
            this.btn_TransactionMaintenance.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_TransactionMaintenance.Size = new System.Drawing.Size(223, 35);
            this.btn_TransactionMaintenance.TabIndex = 38;
            this.btn_TransactionMaintenance.Text = "Transaction Maintenance";
            this.btn_TransactionMaintenance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_TransactionMaintenance.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_TransactionMaintenance.UseVisualStyleBackColor = false;
            this.btn_TransactionMaintenance.Click += new System.EventHandler(this.btn_TransactionMaintenance_Click);
            // 
            // btn_ServiceFileMaintenance
            // 
            this.btn_ServiceFileMaintenance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceFileMaintenance.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceFileMaintenance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_ServiceFileMaintenance.BorderRadius = 0;
            this.btn_ServiceFileMaintenance.BorderSize = 0;
            this.btn_ServiceFileMaintenance.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_ServiceFileMaintenance.FlatAppearance.BorderSize = 0;
            this.btn_ServiceFileMaintenance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ServiceFileMaintenance.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ServiceFileMaintenance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceFileMaintenance.Location = new System.Drawing.Point(0, 210);
            this.btn_ServiceFileMaintenance.Name = "btn_ServiceFileMaintenance";
            this.btn_ServiceFileMaintenance.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_ServiceFileMaintenance.Size = new System.Drawing.Size(223, 35);
            this.btn_ServiceFileMaintenance.TabIndex = 37;
            this.btn_ServiceFileMaintenance.Text = "Service Maintenance";
            this.btn_ServiceFileMaintenance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ServiceFileMaintenance.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceFileMaintenance.UseVisualStyleBackColor = false;
            this.btn_ServiceFileMaintenance.Click += new System.EventHandler(this.btn_ServiceFileMaintenance_Click);
            // 
            // btn_Package
            // 
            this.btn_Package.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Package.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Package.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Package.BorderRadius = 0;
            this.btn_Package.BorderSize = 0;
            this.btn_Package.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Package.FlatAppearance.BorderSize = 0;
            this.btn_Package.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Package.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Package.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Package.Location = new System.Drawing.Point(0, 175);
            this.btn_Package.Name = "btn_Package";
            this.btn_Package.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_Package.Size = new System.Drawing.Size(223, 35);
            this.btn_Package.TabIndex = 36;
            this.btn_Package.Text = "Create Package";
            this.btn_Package.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Package.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Package.UseVisualStyleBackColor = false;
            this.btn_Package.Click += new System.EventHandler(this.btn_Package_Click);
            // 
            // btn_EmployeeList
            // 
            this.btn_EmployeeList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_EmployeeList.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_EmployeeList.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_EmployeeList.BorderRadius = 0;
            this.btn_EmployeeList.BorderSize = 0;
            this.btn_EmployeeList.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_EmployeeList.FlatAppearance.BorderSize = 0;
            this.btn_EmployeeList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EmployeeList.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EmployeeList.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_EmployeeList.Location = new System.Drawing.Point(0, 140);
            this.btn_EmployeeList.Name = "btn_EmployeeList";
            this.btn_EmployeeList.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_EmployeeList.Size = new System.Drawing.Size(223, 35);
            this.btn_EmployeeList.TabIndex = 33;
            this.btn_EmployeeList.Text = "Employee List";
            this.btn_EmployeeList.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_EmployeeList.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_EmployeeList.UseVisualStyleBackColor = false;
            this.btn_EmployeeList.Click += new System.EventHandler(this.btn_EmployeeList_Click);
            // 
            // btn_AddEquipment
            // 
            this.btn_AddEquipment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddEquipment.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddEquipment.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_AddEquipment.BorderRadius = 0;
            this.btn_AddEquipment.BorderSize = 0;
            this.btn_AddEquipment.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_AddEquipment.FlatAppearance.BorderSize = 0;
            this.btn_AddEquipment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AddEquipment.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddEquipment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddEquipment.Location = new System.Drawing.Point(0, 105);
            this.btn_AddEquipment.Name = "btn_AddEquipment";
            this.btn_AddEquipment.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_AddEquipment.Size = new System.Drawing.Size(223, 35);
            this.btn_AddEquipment.TabIndex = 30;
            this.btn_AddEquipment.Text = "Equipment List";
            this.btn_AddEquipment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddEquipment.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddEquipment.UseVisualStyleBackColor = false;
            this.btn_AddEquipment.Click += new System.EventHandler(this.btn_AddEquipment_Click);
            // 
            // btn_AddClient
            // 
            this.btn_AddClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddClient.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddClient.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_AddClient.BorderRadius = 0;
            this.btn_AddClient.BorderSize = 0;
            this.btn_AddClient.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_AddClient.FlatAppearance.BorderSize = 0;
            this.btn_AddClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AddClient.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddClient.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddClient.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddClient.Location = new System.Drawing.Point(0, 70);
            this.btn_AddClient.Name = "btn_AddClient";
            this.btn_AddClient.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_AddClient.Size = new System.Drawing.Size(223, 35);
            this.btn_AddClient.TabIndex = 29;
            this.btn_AddClient.Text = "Client List";
            this.btn_AddClient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddClient.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddClient.UseVisualStyleBackColor = false;
            this.btn_AddClient.Click += new System.EventHandler(this.btn_AddClient_Click);
            // 
            // btn_AddUser
            // 
            this.btn_AddUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddUser.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddUser.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_AddUser.BorderRadius = 0;
            this.btn_AddUser.BorderSize = 0;
            this.btn_AddUser.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_AddUser.FlatAppearance.BorderSize = 0;
            this.btn_AddUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AddUser.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddUser.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddUser.Location = new System.Drawing.Point(0, 35);
            this.btn_AddUser.Name = "btn_AddUser";
            this.btn_AddUser.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_AddUser.Size = new System.Drawing.Size(223, 35);
            this.btn_AddUser.TabIndex = 28;
            this.btn_AddUser.Text = "User List";
            this.btn_AddUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddUser.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddUser.UseVisualStyleBackColor = false;
            this.btn_AddUser.Click += new System.EventHandler(this.btn_AddUser_Click);
            // 
            // btn_AccountDetails
            // 
            this.btn_AccountDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AccountDetails.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AccountDetails.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_AccountDetails.BorderRadius = 0;
            this.btn_AccountDetails.BorderSize = 0;
            this.btn_AccountDetails.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_AccountDetails.FlatAppearance.BorderSize = 0;
            this.btn_AccountDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AccountDetails.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AccountDetails.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AccountDetails.Location = new System.Drawing.Point(0, 0);
            this.btn_AccountDetails.Name = "btn_AccountDetails";
            this.btn_AccountDetails.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_AccountDetails.Size = new System.Drawing.Size(223, 35);
            this.btn_AccountDetails.TabIndex = 27;
            this.btn_AccountDetails.Text = "Account";
            this.btn_AccountDetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AccountDetails.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AccountDetails.UseVisualStyleBackColor = false;
            this.btn_AccountDetails.Click += new System.EventHandler(this.btn_AccountDetails_Click);
            // 
            // btn_Settings
            // 
            this.btn_Settings.BackColor = System.Drawing.Color.Transparent;
            this.btn_Settings.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Settings.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Settings.BorderRadius = 0;
            this.btn_Settings.BorderSize = 0;
            this.btn_Settings.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Settings.FlatAppearance.BorderSize = 0;
            this.btn_Settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Settings.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Settings.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Settings.Image = global::ILAGAN_Management_System.Properties.Resources.iconSettings_removebg_preview1;
            this.btn_Settings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Settings.Location = new System.Drawing.Point(0, 560);
            this.btn_Settings.Name = "btn_Settings";
            this.btn_Settings.Padding = new System.Windows.Forms.Padding(0, 1, 90, 0);
            this.btn_Settings.Size = new System.Drawing.Size(223, 35);
            this.btn_Settings.TabIndex = 28;
            this.btn_Settings.Text = "Setting";
            this.btn_Settings.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Settings.UseVisualStyleBackColor = false;
            this.btn_Settings.Click += new System.EventHandler(this.btn_Settings_Click);
            // 
            // panelReportsSubMenu
            // 
            this.panelReportsSubMenu.AutoSize = true;
            this.panelReportsSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelReportsSubMenu.Controls.Add(this.btn_Sales);
            this.panelReportsSubMenu.Controls.Add(this.btn_InventoryMasterList);
            this.panelReportsSubMenu.Controls.Add(this.btn_EquipmentReleaseLog);
            this.panelReportsSubMenu.Controls.Add(this.btn_ServiceHistory);
            this.panelReportsSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelReportsSubMenu.ForeColor = System.Drawing.Color.Gray;
            this.panelReportsSubMenu.Location = new System.Drawing.Point(0, 420);
            this.panelReportsSubMenu.Name = "panelReportsSubMenu";
            this.panelReportsSubMenu.Size = new System.Drawing.Size(223, 140);
            this.panelReportsSubMenu.TabIndex = 27;
            // 
            // btn_Sales
            // 
            this.btn_Sales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Sales.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Sales.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Sales.BorderRadius = 0;
            this.btn_Sales.BorderSize = 0;
            this.btn_Sales.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Sales.FlatAppearance.BorderSize = 0;
            this.btn_Sales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Sales.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sales.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Sales.Location = new System.Drawing.Point(0, 105);
            this.btn_Sales.Name = "btn_Sales";
            this.btn_Sales.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_Sales.Size = new System.Drawing.Size(223, 35);
            this.btn_Sales.TabIndex = 21;
            this.btn_Sales.Text = "Sales ";
            this.btn_Sales.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Sales.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Sales.UseVisualStyleBackColor = false;
            this.btn_Sales.Click += new System.EventHandler(this.btn_Sales_Click);
            // 
            // btn_InventoryMasterList
            // 
            this.btn_InventoryMasterList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_InventoryMasterList.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_InventoryMasterList.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_InventoryMasterList.BorderRadius = 0;
            this.btn_InventoryMasterList.BorderSize = 0;
            this.btn_InventoryMasterList.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_InventoryMasterList.FlatAppearance.BorderSize = 0;
            this.btn_InventoryMasterList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InventoryMasterList.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InventoryMasterList.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_InventoryMasterList.Location = new System.Drawing.Point(0, 70);
            this.btn_InventoryMasterList.Name = "btn_InventoryMasterList";
            this.btn_InventoryMasterList.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_InventoryMasterList.Size = new System.Drawing.Size(223, 35);
            this.btn_InventoryMasterList.TabIndex = 20;
            this.btn_InventoryMasterList.Text = "Inventory Master List";
            this.btn_InventoryMasterList.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_InventoryMasterList.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_InventoryMasterList.UseVisualStyleBackColor = false;
            this.btn_InventoryMasterList.Click += new System.EventHandler(this.btn_Inventory_Click);
            // 
            // btn_EquipmentReleaseLog
            // 
            this.btn_EquipmentReleaseLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_EquipmentReleaseLog.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_EquipmentReleaseLog.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_EquipmentReleaseLog.BorderRadius = 0;
            this.btn_EquipmentReleaseLog.BorderSize = 0;
            this.btn_EquipmentReleaseLog.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_EquipmentReleaseLog.FlatAppearance.BorderSize = 0;
            this.btn_EquipmentReleaseLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EquipmentReleaseLog.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EquipmentReleaseLog.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_EquipmentReleaseLog.Location = new System.Drawing.Point(0, 35);
            this.btn_EquipmentReleaseLog.Name = "btn_EquipmentReleaseLog";
            this.btn_EquipmentReleaseLog.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_EquipmentReleaseLog.Size = new System.Drawing.Size(223, 35);
            this.btn_EquipmentReleaseLog.TabIndex = 19;
            this.btn_EquipmentReleaseLog.Text = "Equipment Release Log";
            this.btn_EquipmentReleaseLog.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_EquipmentReleaseLog.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_EquipmentReleaseLog.UseVisualStyleBackColor = false;
            this.btn_EquipmentReleaseLog.Click += new System.EventHandler(this.btn_EquipmentReleaseLog_Click);
            // 
            // btn_ServiceHistory
            // 
            this.btn_ServiceHistory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceHistory.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceHistory.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_ServiceHistory.BorderRadius = 0;
            this.btn_ServiceHistory.BorderSize = 0;
            this.btn_ServiceHistory.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_ServiceHistory.FlatAppearance.BorderSize = 0;
            this.btn_ServiceHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ServiceHistory.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ServiceHistory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceHistory.Location = new System.Drawing.Point(0, 0);
            this.btn_ServiceHistory.Name = "btn_ServiceHistory";
            this.btn_ServiceHistory.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_ServiceHistory.Size = new System.Drawing.Size(223, 35);
            this.btn_ServiceHistory.TabIndex = 12;
            this.btn_ServiceHistory.Text = "Service History";
            this.btn_ServiceHistory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ServiceHistory.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceHistory.UseVisualStyleBackColor = false;
            this.btn_ServiceHistory.Click += new System.EventHandler(this.btn_ServiceHistory_Click);
            // 
            // btn_Reports
            // 
            this.btn_Reports.BackColor = System.Drawing.Color.Transparent;
            this.btn_Reports.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Reports.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Reports.BorderRadius = 0;
            this.btn_Reports.BorderSize = 0;
            this.btn_Reports.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Reports.FlatAppearance.BorderSize = 0;
            this.btn_Reports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Reports.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Reports.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Reports.Image = global::ILAGAN_Management_System.Properties.Resources.iconReport_removebg_preview;
            this.btn_Reports.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Reports.Location = new System.Drawing.Point(0, 385);
            this.btn_Reports.Name = "btn_Reports";
            this.btn_Reports.Padding = new System.Windows.Forms.Padding(0, 0, 80, 0);
            this.btn_Reports.Size = new System.Drawing.Size(223, 35);
            this.btn_Reports.TabIndex = 26;
            this.btn_Reports.Text = "Reports";
            this.btn_Reports.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Reports.UseVisualStyleBackColor = false;
            this.btn_Reports.Click += new System.EventHandler(this.btn_Reports_Click);
            // 
            // panelInventorySubMenu
            // 
            this.panelInventorySubMenu.AutoSize = true;
            this.panelInventorySubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelInventorySubMenu.Controls.Add(this.btn_ReturnEquipment);
            this.panelInventorySubMenu.Controls.Add(this.btn_Release);
            this.panelInventorySubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelInventorySubMenu.ForeColor = System.Drawing.Color.Gray;
            this.panelInventorySubMenu.Location = new System.Drawing.Point(0, 315);
            this.panelInventorySubMenu.Name = "panelInventorySubMenu";
            this.panelInventorySubMenu.Size = new System.Drawing.Size(223, 70);
            this.panelInventorySubMenu.TabIndex = 23;
            // 
            // btn_ReturnEquipment
            // 
            this.btn_ReturnEquipment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ReturnEquipment.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ReturnEquipment.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_ReturnEquipment.BorderRadius = 0;
            this.btn_ReturnEquipment.BorderSize = 0;
            this.btn_ReturnEquipment.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_ReturnEquipment.FlatAppearance.BorderSize = 0;
            this.btn_ReturnEquipment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ReturnEquipment.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ReturnEquipment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ReturnEquipment.Location = new System.Drawing.Point(0, 35);
            this.btn_ReturnEquipment.Name = "btn_ReturnEquipment";
            this.btn_ReturnEquipment.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_ReturnEquipment.Size = new System.Drawing.Size(223, 35);
            this.btn_ReturnEquipment.TabIndex = 14;
            this.btn_ReturnEquipment.Text = "Return Equipment";
            this.btn_ReturnEquipment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ReturnEquipment.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ReturnEquipment.UseVisualStyleBackColor = false;
            this.btn_ReturnEquipment.Click += new System.EventHandler(this.btn_ReturnEquipment_Click);
            // 
            // btn_Release
            // 
            this.btn_Release.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Release.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Release.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Release.BorderRadius = 0;
            this.btn_Release.BorderSize = 0;
            this.btn_Release.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Release.FlatAppearance.BorderSize = 0;
            this.btn_Release.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Release.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Release.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Release.Location = new System.Drawing.Point(0, 0);
            this.btn_Release.Name = "btn_Release";
            this.btn_Release.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_Release.Size = new System.Drawing.Size(223, 35);
            this.btn_Release.TabIndex = 13;
            this.btn_Release.Text = "Release Equipment";
            this.btn_Release.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Release.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Release.UseVisualStyleBackColor = false;
            this.btn_Release.Click += new System.EventHandler(this.btn_Release_Click);
            // 
            // btn_Inventory
            // 
            this.btn_Inventory.BackColor = System.Drawing.Color.Transparent;
            this.btn_Inventory.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Inventory.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Inventory.BorderRadius = 0;
            this.btn_Inventory.BorderSize = 0;
            this.btn_Inventory.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Inventory.FlatAppearance.BorderSize = 0;
            this.btn_Inventory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Inventory.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Inventory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Inventory.Image = global::ILAGAN_Management_System.Properties.Resources.iconInventory_removebg_preview;
            this.btn_Inventory.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Inventory.Location = new System.Drawing.Point(0, 280);
            this.btn_Inventory.Name = "btn_Inventory";
            this.btn_Inventory.Padding = new System.Windows.Forms.Padding(0, 0, 70, 0);
            this.btn_Inventory.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_Inventory.Size = new System.Drawing.Size(223, 35);
            this.btn_Inventory.TabIndex = 22;
            this.btn_Inventory.Text = "Inventory";
            this.btn_Inventory.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Inventory.UseVisualStyleBackColor = false;
            this.btn_Inventory.Click += new System.EventHandler(this.btn_Inventory_Click_1);
            // 
            // panelTransactionSubMenu
            // 
            this.panelTransactionSubMenu.AutoSize = true;
            this.panelTransactionSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelTransactionSubMenu.Controls.Add(this.btn_InstallmentPayment);
            this.panelTransactionSubMenu.Controls.Add(this.btn_Payment);
            this.panelTransactionSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTransactionSubMenu.ForeColor = System.Drawing.Color.Gray;
            this.panelTransactionSubMenu.Location = new System.Drawing.Point(0, 210);
            this.panelTransactionSubMenu.Name = "panelTransactionSubMenu";
            this.panelTransactionSubMenu.Size = new System.Drawing.Size(223, 70);
            this.panelTransactionSubMenu.TabIndex = 17;
            // 
            // btn_InstallmentPayment
            // 
            this.btn_InstallmentPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_InstallmentPayment.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_InstallmentPayment.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_InstallmentPayment.BorderRadius = 0;
            this.btn_InstallmentPayment.BorderSize = 0;
            this.btn_InstallmentPayment.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_InstallmentPayment.FlatAppearance.BorderSize = 0;
            this.btn_InstallmentPayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InstallmentPayment.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InstallmentPayment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_InstallmentPayment.Location = new System.Drawing.Point(0, 35);
            this.btn_InstallmentPayment.Name = "btn_InstallmentPayment";
            this.btn_InstallmentPayment.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_InstallmentPayment.Size = new System.Drawing.Size(223, 35);
            this.btn_InstallmentPayment.TabIndex = 15;
            this.btn_InstallmentPayment.Text = "Installment Payment";
            this.btn_InstallmentPayment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_InstallmentPayment.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_InstallmentPayment.UseVisualStyleBackColor = false;
            this.btn_InstallmentPayment.Click += new System.EventHandler(this.btn_InstallmentPayment_Click_1);
            // 
            // btn_Payment
            // 
            this.btn_Payment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Payment.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Payment.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Payment.BorderRadius = 0;
            this.btn_Payment.BorderSize = 0;
            this.btn_Payment.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Payment.FlatAppearance.BorderSize = 0;
            this.btn_Payment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Payment.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Payment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Payment.Location = new System.Drawing.Point(0, 0);
            this.btn_Payment.Name = "btn_Payment";
            this.btn_Payment.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_Payment.Size = new System.Drawing.Size(223, 35);
            this.btn_Payment.TabIndex = 14;
            this.btn_Payment.Text = "Payment";
            this.btn_Payment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Payment.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Payment.UseVisualStyleBackColor = false;
            this.btn_Payment.Click += new System.EventHandler(this.btn_Payment_Click);
            // 
            // btn_Transaction
            // 
            this.btn_Transaction.BackColor = System.Drawing.Color.Transparent;
            this.btn_Transaction.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Transaction.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Transaction.BorderRadius = 0;
            this.btn_Transaction.BorderSize = 0;
            this.btn_Transaction.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Transaction.FlatAppearance.BorderSize = 0;
            this.btn_Transaction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Transaction.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Transaction.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Transaction.Image = global::ILAGAN_Management_System.Properties.Resources.iconPayment_removebg_preview__1_;
            this.btn_Transaction.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Transaction.Location = new System.Drawing.Point(0, 175);
            this.btn_Transaction.Name = "btn_Transaction";
            this.btn_Transaction.Padding = new System.Windows.Forms.Padding(0, 0, 55, 0);
            this.btn_Transaction.Size = new System.Drawing.Size(223, 35);
            this.btn_Transaction.TabIndex = 16;
            this.btn_Transaction.Text = "Transaction";
            this.btn_Transaction.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Transaction.UseVisualStyleBackColor = false;
            this.btn_Transaction.Click += new System.EventHandler(this.btn_Transaction_Click);
            // 
            // panelServiceSubMenu
            // 
            this.panelServiceSubMenu.AutoSize = true;
            this.panelServiceSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelServiceSubMenu.Controls.Add(this.btn_ServiceRequest);
            this.panelServiceSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelServiceSubMenu.ForeColor = System.Drawing.Color.Gray;
            this.panelServiceSubMenu.Location = new System.Drawing.Point(0, 140);
            this.panelServiceSubMenu.Name = "panelServiceSubMenu";
            this.panelServiceSubMenu.Size = new System.Drawing.Size(223, 35);
            this.panelServiceSubMenu.TabIndex = 15;
            // 
            // btn_ServiceRequest
            // 
            this.btn_ServiceRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceRequest.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceRequest.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_ServiceRequest.BorderRadius = 0;
            this.btn_ServiceRequest.BorderSize = 0;
            this.btn_ServiceRequest.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_ServiceRequest.FlatAppearance.BorderSize = 0;
            this.btn_ServiceRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ServiceRequest.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ServiceRequest.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceRequest.Location = new System.Drawing.Point(0, 0);
            this.btn_ServiceRequest.Name = "btn_ServiceRequest";
            this.btn_ServiceRequest.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_ServiceRequest.Size = new System.Drawing.Size(223, 35);
            this.btn_ServiceRequest.TabIndex = 14;
            this.btn_ServiceRequest.Text = "Service Request";
            this.btn_ServiceRequest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ServiceRequest.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceRequest.UseVisualStyleBackColor = false;
            this.btn_ServiceRequest.Click += new System.EventHandler(this.btn_ServiceRequest_Click);
            // 
            // btn_Service
            // 
            this.btn_Service.BackColor = System.Drawing.Color.Transparent;
            this.btn_Service.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Service.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Service.BorderRadius = 0;
            this.btn_Service.BorderSize = 0;
            this.btn_Service.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Service.FlatAppearance.BorderSize = 0;
            this.btn_Service.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Service.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Service.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Service.Image = global::ILAGAN_Management_System.Properties.Resources.iconService_removebg_preview__1_;
            this.btn_Service.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Service.Location = new System.Drawing.Point(0, 105);
            this.btn_Service.Name = "btn_Service";
            this.btn_Service.Padding = new System.Windows.Forms.Padding(0, 0, 85, 0);
            this.btn_Service.Size = new System.Drawing.Size(223, 35);
            this.btn_Service.TabIndex = 14;
            this.btn_Service.Text = "Service";
            this.btn_Service.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Service.UseVisualStyleBackColor = false;
            this.btn_Service.Click += new System.EventHandler(this.btn_Service_Click);
            // 
            // panelUserSubmenu
            // 
            this.panelUserSubmenu.AutoSize = true;
            this.panelUserSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelUserSubmenu.Controls.Add(this.btn_UserLog);
            this.panelUserSubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelUserSubmenu.ForeColor = System.Drawing.Color.Gray;
            this.panelUserSubmenu.Location = new System.Drawing.Point(0, 70);
            this.panelUserSubmenu.Name = "panelUserSubmenu";
            this.panelUserSubmenu.Size = new System.Drawing.Size(223, 35);
            this.panelUserSubmenu.TabIndex = 12;
            // 
            // btn_UserLog
            // 
            this.btn_UserLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_UserLog.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_UserLog.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_UserLog.BorderRadius = 0;
            this.btn_UserLog.BorderSize = 0;
            this.btn_UserLog.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_UserLog.FlatAppearance.BorderSize = 0;
            this.btn_UserLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UserLog.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_UserLog.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_UserLog.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_UserLog.Location = new System.Drawing.Point(0, 0);
            this.btn_UserLog.Name = "btn_UserLog";
            this.btn_UserLog.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_UserLog.Size = new System.Drawing.Size(223, 35);
            this.btn_UserLog.TabIndex = 13;
            this.btn_UserLog.Text = "Users Logs";
            this.btn_UserLog.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_UserLog.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_UserLog.UseVisualStyleBackColor = false;
            this.btn_UserLog.Click += new System.EventHandler(this.btn_UserLog_Click);
            // 
            // btn_User
            // 
            this.btn_User.BackColor = System.Drawing.Color.Transparent;
            this.btn_User.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_User.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_User.BorderRadius = 0;
            this.btn_User.BorderSize = 0;
            this.btn_User.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_User.FlatAppearance.BorderSize = 0;
            this.btn_User.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_User.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_User.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_User.Image = global::ILAGAN_Management_System.Properties.Resources.iconUser_removebg_preview__2_;
            this.btn_User.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_User.Location = new System.Drawing.Point(0, 35);
            this.btn_User.Name = "btn_User";
            this.btn_User.Padding = new System.Windows.Forms.Padding(0, 0, 95, 0);
            this.btn_User.Size = new System.Drawing.Size(223, 35);
            this.btn_User.TabIndex = 11;
            this.btn_User.Text = "User";
            this.btn_User.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_User.UseVisualStyleBackColor = false;
            this.btn_User.Click += new System.EventHandler(this.btn_User_Click);
            // 
            // btn_Home
            // 
            this.btn_Home.BackColor = System.Drawing.Color.Transparent;
            this.btn_Home.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Home.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Home.BorderRadius = 0;
            this.btn_Home.BorderSize = 0;
            this.btn_Home.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Home.FlatAppearance.BorderSize = 0;
            this.btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Home.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Home.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Home.Image = global::ILAGAN_Management_System.Properties.Resources.iconHome_removebg_preview__1_;
            this.btn_Home.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Home.Location = new System.Drawing.Point(0, 0);
            this.btn_Home.Name = "btn_Home";
            this.btn_Home.Padding = new System.Windows.Forms.Padding(0, 0, 90, 0);
            this.btn_Home.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_Home.Size = new System.Drawing.Size(223, 35);
            this.btn_Home.TabIndex = 11;
            this.btn_Home.Text = "Home";
            this.btn_Home.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Home.UseVisualStyleBackColor = false;
            this.btn_Home.Click += new System.EventHandler(this.btn_Home_Click);
            // 
            // TransactionMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 662);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Name = "TransactionMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TransactionMaintenance";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PlanList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DiscountList)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panelSettingsSubMenu.ResumeLayout(false);
            this.panelReportsSubMenu.ResumeLayout(false);
            this.panelInventorySubMenu.ResumeLayout(false);
            this.panelTransactionSubMenu.ResumeLayout(false);
            this.panelServiceSubMenu.ResumeLayout(false);
            this.panelUserSubmenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private RoundedButton btnLogout;
        private System.Windows.Forms.Label SystemNamelbl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_DiscountName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_DiscountRate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgv_DiscountList;
        private System.Windows.Forms.Label label9;
        private RoundedButton btn_Delete;
        private RoundedButton btn_Update;
        private RoundedButton btn_Add;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private RoundedButton btn_DeletePlan;
        private RoundedButton btn_EditPlan;
        private RoundedButton btn_Addplan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_PlanName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_NumberOfPayments;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dgv_PlanList;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_PaymentInterval;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelSettingsSubMenu;
        private RoundedButton btn_TransactionMaintenance;
        private RoundedButton btn_ServiceFileMaintenance;
        private RoundedButton btn_Package;
        private RoundedButton btn_EmployeeList;
        private RoundedButton btn_AddEquipment;
        private RoundedButton btn_AddClient;
        private RoundedButton btn_AddUser;
        private RoundedButton btn_AccountDetails;
        private RoundedButton btn_Settings;
        private System.Windows.Forms.Panel panelReportsSubMenu;
        private RoundedButton btn_Sales;
        private RoundedButton btn_InventoryMasterList;
        private RoundedButton btn_EquipmentReleaseLog;
        private RoundedButton btn_ServiceHistory;
        private RoundedButton btn_Reports;
        private System.Windows.Forms.Panel panelInventorySubMenu;
        private RoundedButton btn_ReturnEquipment;
        private RoundedButton btn_Release;
        private RoundedButton btn_Inventory;
        private System.Windows.Forms.Panel panelTransactionSubMenu;
        private RoundedButton btn_InstallmentPayment;
        private RoundedButton btn_Payment;
        private RoundedButton btn_Transaction;
        private System.Windows.Forms.Panel panelServiceSubMenu;
        private RoundedButton btn_ServiceRequest;
        private RoundedButton btn_Service;
        private System.Windows.Forms.Panel panelUserSubmenu;
        private RoundedButton btn_UserLog;
        private RoundedButton btn_User;
        private RoundedButton btn_Home;
    }
}
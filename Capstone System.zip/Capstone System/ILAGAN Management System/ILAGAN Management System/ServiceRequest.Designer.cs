﻿namespace ILAGAN_Management_System
{
    partial class ServiceRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnLogout = new ILAGAN_Management_System.RoundedButton();
            this.SystemNamelbl = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dgv_ServiceRequestRecords = new System.Windows.Forms.DataGridView();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.btn_EditUser = new ILAGAN_Management_System.RoundedButton();
            this.btnNewUser = new ILAGAN_Management_System.RoundedButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelSettingsSubMenu = new System.Windows.Forms.Panel();
            this.btn_ChangePassword = new ILAGAN_Management_System.RoundedButton();
            this.btn_AccountDetails = new ILAGAN_Management_System.RoundedButton();
            this.btn_EmployeeList = new ILAGAN_Management_System.RoundedButton();
            this.btn_Settings = new ILAGAN_Management_System.RoundedButton();
            this.panelReportsSubMenu = new System.Windows.Forms.Panel();
            this.btn_EquipmentNarrative = new ILAGAN_Management_System.RoundedButton();
            this.btn_Sales = new ILAGAN_Management_System.RoundedButton();
            this.btn_InventoryMasterList = new ILAGAN_Management_System.RoundedButton();
            this.btn_EquipmentReleaseLog = new ILAGAN_Management_System.RoundedButton();
            this.btn_ServiceHistory = new ILAGAN_Management_System.RoundedButton();
            this.btn_Reports = new ILAGAN_Management_System.RoundedButton();
            this.panelInventorySubMenu = new System.Windows.Forms.Panel();
            this.btn_AddEquipment = new ILAGAN_Management_System.RoundedButton();
            this.btn_Inventory = new ILAGAN_Management_System.RoundedButton();
            this.panelTransactionSubMenu = new System.Windows.Forms.Panel();
            this.btn_InstallmentPayment = new ILAGAN_Management_System.RoundedButton();
            this.btn_Payment = new ILAGAN_Management_System.RoundedButton();
            this.btn_Transaction = new ILAGAN_Management_System.RoundedButton();
            this.panelServiceSubMenu = new System.Windows.Forms.Panel();
            this.btn_Package = new ILAGAN_Management_System.RoundedButton();
            this.btn_ServiceRequest = new ILAGAN_Management_System.RoundedButton();
            this.btn_AddClient = new ILAGAN_Management_System.RoundedButton();
            this.btn_Service = new ILAGAN_Management_System.RoundedButton();
            this.panelUserSubmenu = new System.Windows.Forms.Panel();
            this.btn_Permission = new ILAGAN_Management_System.RoundedButton();
            this.btn_UserLog = new ILAGAN_Management_System.RoundedButton();
            this.btn_AddUser = new ILAGAN_Management_System.RoundedButton();
            this.btn_User = new ILAGAN_Management_System.RoundedButton();
            this.btn_Home = new ILAGAN_Management_System.RoundedButton();
            this.Complete_Service = new System.Windows.Forms.DataGridViewButtonColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ServiceRequestRecords)).BeginInit();
            this.panel2.SuspendLayout();
            this.panelSettingsSubMenu.SuspendLayout();
            this.panelReportsSubMenu.SuspendLayout();
            this.panelInventorySubMenu.SuspendLayout();
            this.panelTransactionSubMenu.SuspendLayout();
            this.panelServiceSubMenu.SuspendLayout();
            this.panelUserSubmenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.SystemNamelbl);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.panel1.Size = new System.Drawing.Size(984, 100);
            this.panel1.TabIndex = 4;
            // 
            // btnLogout
            // 
            this.btnLogout.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnLogout.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnLogout.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btnLogout.BorderRadius = 5;
            this.btnLogout.BorderSize = 0;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Location = new System.Drawing.Point(877, 40);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(80, 30);
            this.btnLogout.TabIndex = 8;
            this.btnLogout.Text = "Log out";
            this.btnLogout.TextColor = System.Drawing.Color.White;
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // SystemNamelbl
            // 
            this.SystemNamelbl.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SystemNamelbl.ForeColor = System.Drawing.Color.Black;
            this.SystemNamelbl.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.SystemNamelbl.Location = new System.Drawing.Point(111, 31);
            this.SystemNamelbl.Name = "SystemNamelbl";
            this.SystemNamelbl.Size = new System.Drawing.Size(209, 47);
            this.SystemNamelbl.TabIndex = 4;
            this.SystemNamelbl.Text = "Ilagan Funera Home Management System";
            this.SystemNamelbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(38, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(67, 67);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.AutoScroll = true;
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.dgv_ServiceRequestRecords);
            this.panel3.Controls.Add(this.txtsearch);
            this.panel3.Controls.Add(this.btn_EditUser);
            this.panel3.Controls.Add(this.btnNewUser);
            this.panel3.Location = new System.Drawing.Point(238, 100);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(748, 564);
            this.panel3.TabIndex = 5;
            // 
            // dgv_ServiceRequestRecords
            // 
            this.dgv_ServiceRequestRecords.AllowUserToAddRows = false;
            this.dgv_ServiceRequestRecords.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_ServiceRequestRecords.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_ServiceRequestRecords.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_ServiceRequestRecords.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_ServiceRequestRecords.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_ServiceRequestRecords.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_ServiceRequestRecords.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_ServiceRequestRecords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_ServiceRequestRecords.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Complete_Service});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 9F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_ServiceRequestRecords.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_ServiceRequestRecords.Location = new System.Drawing.Point(3, 80);
            this.dgv_ServiceRequestRecords.Name = "dgv_ServiceRequestRecords";
            this.dgv_ServiceRequestRecords.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_ServiceRequestRecords.RowHeadersVisible = false;
            this.dgv_ServiceRequestRecords.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_ServiceRequestRecords.Size = new System.Drawing.Size(745, 479);
            this.dgv_ServiceRequestRecords.TabIndex = 190;
            this.dgv_ServiceRequestRecords.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_ServiceRequestRecords_CellContentClick);
            // 
            // txtsearch
            // 
            this.txtsearch.AccessibleName = "";
            this.txtsearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearch.Location = new System.Drawing.Point(7, 45);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(172, 24);
            this.txtsearch.TabIndex = 17;
            this.txtsearch.Tag = "";
            this.txtsearch.TextChanged += new System.EventHandler(this.txtsearch_TextChanged);
            // 
            // btn_EditUser
            // 
            this.btn_EditUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_EditUser.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_EditUser.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_EditUser.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_EditUser.BorderRadius = 5;
            this.btn_EditUser.BorderSize = 0;
            this.btn_EditUser.FlatAppearance.BorderSize = 0;
            this.btn_EditUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EditUser.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EditUser.ForeColor = System.Drawing.Color.White;
            this.btn_EditUser.Location = new System.Drawing.Point(680, 42);
            this.btn_EditUser.Name = "btn_EditUser";
            this.btn_EditUser.Size = new System.Drawing.Size(64, 31);
            this.btn_EditUser.TabIndex = 18;
            this.btn_EditUser.Text = "Edit";
            this.btn_EditUser.TextColor = System.Drawing.Color.White;
            this.btn_EditUser.UseVisualStyleBackColor = false;
            // 
            // btnNewUser
            // 
            this.btnNewUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnNewUser.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnNewUser.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btnNewUser.BorderRadius = 5;
            this.btnNewUser.BorderSize = 0;
            this.btnNewUser.FlatAppearance.BorderSize = 0;
            this.btnNewUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewUser.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewUser.ForeColor = System.Drawing.Color.White;
            this.btnNewUser.Location = new System.Drawing.Point(7, 5);
            this.btnNewUser.Name = "btnNewUser";
            this.btnNewUser.Size = new System.Drawing.Size(113, 31);
            this.btnNewUser.TabIndex = 16;
            this.btnNewUser.Text = "Create Request";
            this.btnNewUser.TextColor = System.Drawing.Color.White;
            this.btnNewUser.UseVisualStyleBackColor = false;
            this.btnNewUser.Click += new System.EventHandler(this.btnNewUser_Click);
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(210)))), ((int)(((byte)(159)))));
            this.panel2.Controls.Add(this.panelSettingsSubMenu);
            this.panel2.Controls.Add(this.btn_Settings);
            this.panel2.Controls.Add(this.panelReportsSubMenu);
            this.panel2.Controls.Add(this.btn_Reports);
            this.panel2.Controls.Add(this.panelInventorySubMenu);
            this.panel2.Controls.Add(this.btn_Inventory);
            this.panel2.Controls.Add(this.panelTransactionSubMenu);
            this.panel2.Controls.Add(this.btn_Transaction);
            this.panel2.Controls.Add(this.panelServiceSubMenu);
            this.panel2.Controls.Add(this.btn_Service);
            this.panel2.Controls.Add(this.panelUserSubmenu);
            this.panel2.Controls.Add(this.btn_User);
            this.panel2.Controls.Add(this.btn_Home);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(240, 562);
            this.panel2.TabIndex = 6;
            // 
            // panelSettingsSubMenu
            // 
            this.panelSettingsSubMenu.AutoSize = true;
            this.panelSettingsSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelSettingsSubMenu.Controls.Add(this.btn_ChangePassword);
            this.panelSettingsSubMenu.Controls.Add(this.btn_AccountDetails);
            this.panelSettingsSubMenu.Controls.Add(this.btn_EmployeeList);
            this.panelSettingsSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSettingsSubMenu.ForeColor = System.Drawing.Color.Gray;
            this.panelSettingsSubMenu.Location = new System.Drawing.Point(0, 735);
            this.panelSettingsSubMenu.Name = "panelSettingsSubMenu";
            this.panelSettingsSubMenu.Size = new System.Drawing.Size(223, 105);
            this.panelSettingsSubMenu.TabIndex = 29;
            // 
            // btn_ChangePassword
            // 
            this.btn_ChangePassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ChangePassword.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ChangePassword.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_ChangePassword.BorderRadius = 0;
            this.btn_ChangePassword.BorderSize = 0;
            this.btn_ChangePassword.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_ChangePassword.FlatAppearance.BorderSize = 0;
            this.btn_ChangePassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ChangePassword.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ChangePassword.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ChangePassword.Location = new System.Drawing.Point(0, 70);
            this.btn_ChangePassword.Name = "btn_ChangePassword";
            this.btn_ChangePassword.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_ChangePassword.Size = new System.Drawing.Size(223, 35);
            this.btn_ChangePassword.TabIndex = 15;
            this.btn_ChangePassword.Text = "Change Password";
            this.btn_ChangePassword.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ChangePassword.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ChangePassword.UseVisualStyleBackColor = false;
            this.btn_ChangePassword.Click += new System.EventHandler(this.btn_ChangePassword_Click);
            // 
            // btn_AccountDetails
            // 
            this.btn_AccountDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AccountDetails.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AccountDetails.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_AccountDetails.BorderRadius = 0;
            this.btn_AccountDetails.BorderSize = 0;
            this.btn_AccountDetails.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_AccountDetails.FlatAppearance.BorderSize = 0;
            this.btn_AccountDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AccountDetails.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AccountDetails.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AccountDetails.Location = new System.Drawing.Point(0, 35);
            this.btn_AccountDetails.Name = "btn_AccountDetails";
            this.btn_AccountDetails.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_AccountDetails.Size = new System.Drawing.Size(223, 35);
            this.btn_AccountDetails.TabIndex = 14;
            this.btn_AccountDetails.Text = "Account Details";
            this.btn_AccountDetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AccountDetails.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AccountDetails.UseVisualStyleBackColor = false;
            this.btn_AccountDetails.Click += new System.EventHandler(this.btn_AccountDetails_Click);
            // 
            // btn_EmployeeList
            // 
            this.btn_EmployeeList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_EmployeeList.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_EmployeeList.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_EmployeeList.BorderRadius = 0;
            this.btn_EmployeeList.BorderSize = 0;
            this.btn_EmployeeList.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_EmployeeList.FlatAppearance.BorderSize = 0;
            this.btn_EmployeeList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EmployeeList.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EmployeeList.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_EmployeeList.Location = new System.Drawing.Point(0, 0);
            this.btn_EmployeeList.Name = "btn_EmployeeList";
            this.btn_EmployeeList.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_EmployeeList.Size = new System.Drawing.Size(223, 35);
            this.btn_EmployeeList.TabIndex = 13;
            this.btn_EmployeeList.Text = "Employee List";
            this.btn_EmployeeList.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_EmployeeList.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_EmployeeList.UseVisualStyleBackColor = false;
            this.btn_EmployeeList.Click += new System.EventHandler(this.btn_EmployeeList_Click);
            // 
            // btn_Settings
            // 
            this.btn_Settings.BackColor = System.Drawing.Color.Transparent;
            this.btn_Settings.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Settings.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Settings.BorderRadius = 0;
            this.btn_Settings.BorderSize = 0;
            this.btn_Settings.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Settings.FlatAppearance.BorderSize = 0;
            this.btn_Settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Settings.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Settings.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Settings.Image = global::ILAGAN_Management_System.Properties.Resources.iconSettings_removebg_preview1;
            this.btn_Settings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Settings.Location = new System.Drawing.Point(0, 700);
            this.btn_Settings.Name = "btn_Settings";
            this.btn_Settings.Padding = new System.Windows.Forms.Padding(0, 1, 90, 0);
            this.btn_Settings.Size = new System.Drawing.Size(223, 35);
            this.btn_Settings.TabIndex = 28;
            this.btn_Settings.Text = "Setting";
            this.btn_Settings.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Settings.UseVisualStyleBackColor = false;
            this.btn_Settings.Click += new System.EventHandler(this.btn_Settings_Click);
            // 
            // panelReportsSubMenu
            // 
            this.panelReportsSubMenu.AutoSize = true;
            this.panelReportsSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelReportsSubMenu.Controls.Add(this.btn_EquipmentNarrative);
            this.panelReportsSubMenu.Controls.Add(this.btn_Sales);
            this.panelReportsSubMenu.Controls.Add(this.btn_InventoryMasterList);
            this.panelReportsSubMenu.Controls.Add(this.btn_EquipmentReleaseLog);
            this.panelReportsSubMenu.Controls.Add(this.btn_ServiceHistory);
            this.panelReportsSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelReportsSubMenu.ForeColor = System.Drawing.Color.Gray;
            this.panelReportsSubMenu.Location = new System.Drawing.Point(0, 525);
            this.panelReportsSubMenu.Name = "panelReportsSubMenu";
            this.panelReportsSubMenu.Size = new System.Drawing.Size(223, 175);
            this.panelReportsSubMenu.TabIndex = 27;
            // 
            // btn_EquipmentNarrative
            // 
            this.btn_EquipmentNarrative.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_EquipmentNarrative.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_EquipmentNarrative.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_EquipmentNarrative.BorderRadius = 0;
            this.btn_EquipmentNarrative.BorderSize = 0;
            this.btn_EquipmentNarrative.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_EquipmentNarrative.FlatAppearance.BorderSize = 0;
            this.btn_EquipmentNarrative.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EquipmentNarrative.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EquipmentNarrative.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_EquipmentNarrative.Location = new System.Drawing.Point(0, 140);
            this.btn_EquipmentNarrative.Name = "btn_EquipmentNarrative";
            this.btn_EquipmentNarrative.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_EquipmentNarrative.Size = new System.Drawing.Size(223, 35);
            this.btn_EquipmentNarrative.TabIndex = 22;
            this.btn_EquipmentNarrative.Text = "Equipment Narrative";
            this.btn_EquipmentNarrative.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_EquipmentNarrative.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_EquipmentNarrative.UseVisualStyleBackColor = false;
            this.btn_EquipmentNarrative.Click += new System.EventHandler(this.btn_EquipmentNarrative_Click);
            // 
            // btn_Sales
            // 
            this.btn_Sales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Sales.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Sales.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Sales.BorderRadius = 0;
            this.btn_Sales.BorderSize = 0;
            this.btn_Sales.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Sales.FlatAppearance.BorderSize = 0;
            this.btn_Sales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Sales.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sales.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Sales.Location = new System.Drawing.Point(0, 105);
            this.btn_Sales.Name = "btn_Sales";
            this.btn_Sales.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_Sales.Size = new System.Drawing.Size(223, 35);
            this.btn_Sales.TabIndex = 21;
            this.btn_Sales.Text = "Sales ";
            this.btn_Sales.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Sales.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Sales.UseVisualStyleBackColor = false;
            this.btn_Sales.Click += new System.EventHandler(this.btn_Sales_Click);
            // 
            // btn_InventoryMasterList
            // 
            this.btn_InventoryMasterList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_InventoryMasterList.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_InventoryMasterList.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_InventoryMasterList.BorderRadius = 0;
            this.btn_InventoryMasterList.BorderSize = 0;
            this.btn_InventoryMasterList.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_InventoryMasterList.FlatAppearance.BorderSize = 0;
            this.btn_InventoryMasterList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InventoryMasterList.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InventoryMasterList.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_InventoryMasterList.Location = new System.Drawing.Point(0, 70);
            this.btn_InventoryMasterList.Name = "btn_InventoryMasterList";
            this.btn_InventoryMasterList.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_InventoryMasterList.Size = new System.Drawing.Size(223, 35);
            this.btn_InventoryMasterList.TabIndex = 20;
            this.btn_InventoryMasterList.Text = "Inventory Master List";
            this.btn_InventoryMasterList.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_InventoryMasterList.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_InventoryMasterList.UseVisualStyleBackColor = false;
            this.btn_InventoryMasterList.Click += new System.EventHandler(this.btn_Inventory_Click);
            // 
            // btn_EquipmentReleaseLog
            // 
            this.btn_EquipmentReleaseLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_EquipmentReleaseLog.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_EquipmentReleaseLog.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_EquipmentReleaseLog.BorderRadius = 0;
            this.btn_EquipmentReleaseLog.BorderSize = 0;
            this.btn_EquipmentReleaseLog.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_EquipmentReleaseLog.FlatAppearance.BorderSize = 0;
            this.btn_EquipmentReleaseLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EquipmentReleaseLog.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EquipmentReleaseLog.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_EquipmentReleaseLog.Location = new System.Drawing.Point(0, 35);
            this.btn_EquipmentReleaseLog.Name = "btn_EquipmentReleaseLog";
            this.btn_EquipmentReleaseLog.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_EquipmentReleaseLog.Size = new System.Drawing.Size(223, 35);
            this.btn_EquipmentReleaseLog.TabIndex = 19;
            this.btn_EquipmentReleaseLog.Text = "Equipment Release Log";
            this.btn_EquipmentReleaseLog.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_EquipmentReleaseLog.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_EquipmentReleaseLog.UseVisualStyleBackColor = false;
            this.btn_EquipmentReleaseLog.Click += new System.EventHandler(this.btn_EquipmentReleaseLog_Click);
            // 
            // btn_ServiceHistory
            // 
            this.btn_ServiceHistory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceHistory.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceHistory.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_ServiceHistory.BorderRadius = 0;
            this.btn_ServiceHistory.BorderSize = 0;
            this.btn_ServiceHistory.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_ServiceHistory.FlatAppearance.BorderSize = 0;
            this.btn_ServiceHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ServiceHistory.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ServiceHistory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceHistory.Location = new System.Drawing.Point(0, 0);
            this.btn_ServiceHistory.Name = "btn_ServiceHistory";
            this.btn_ServiceHistory.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_ServiceHistory.Size = new System.Drawing.Size(223, 35);
            this.btn_ServiceHistory.TabIndex = 12;
            this.btn_ServiceHistory.Text = "Service History";
            this.btn_ServiceHistory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ServiceHistory.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceHistory.UseVisualStyleBackColor = false;
            this.btn_ServiceHistory.Click += new System.EventHandler(this.btn_ServiceHistory_Click);
            // 
            // btn_Reports
            // 
            this.btn_Reports.BackColor = System.Drawing.Color.Transparent;
            this.btn_Reports.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Reports.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Reports.BorderRadius = 0;
            this.btn_Reports.BorderSize = 0;
            this.btn_Reports.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Reports.FlatAppearance.BorderSize = 0;
            this.btn_Reports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Reports.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Reports.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Reports.Image = global::ILAGAN_Management_System.Properties.Resources.iconReport_removebg_preview;
            this.btn_Reports.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Reports.Location = new System.Drawing.Point(0, 490);
            this.btn_Reports.Name = "btn_Reports";
            this.btn_Reports.Padding = new System.Windows.Forms.Padding(0, 0, 80, 0);
            this.btn_Reports.Size = new System.Drawing.Size(223, 35);
            this.btn_Reports.TabIndex = 26;
            this.btn_Reports.Text = "Reports";
            this.btn_Reports.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Reports.UseVisualStyleBackColor = false;
            this.btn_Reports.Click += new System.EventHandler(this.btn_Reports_Click);
            // 
            // panelInventorySubMenu
            // 
            this.panelInventorySubMenu.AutoSize = true;
            this.panelInventorySubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelInventorySubMenu.Controls.Add(this.btn_AddEquipment);
            this.panelInventorySubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelInventorySubMenu.ForeColor = System.Drawing.Color.Gray;
            this.panelInventorySubMenu.Location = new System.Drawing.Point(0, 455);
            this.panelInventorySubMenu.Name = "panelInventorySubMenu";
            this.panelInventorySubMenu.Size = new System.Drawing.Size(223, 35);
            this.panelInventorySubMenu.TabIndex = 23;
            // 
            // btn_AddEquipment
            // 
            this.btn_AddEquipment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddEquipment.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddEquipment.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_AddEquipment.BorderRadius = 0;
            this.btn_AddEquipment.BorderSize = 0;
            this.btn_AddEquipment.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_AddEquipment.FlatAppearance.BorderSize = 0;
            this.btn_AddEquipment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AddEquipment.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddEquipment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddEquipment.Location = new System.Drawing.Point(0, 0);
            this.btn_AddEquipment.Name = "btn_AddEquipment";
            this.btn_AddEquipment.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_AddEquipment.Size = new System.Drawing.Size(223, 35);
            this.btn_AddEquipment.TabIndex = 12;
            this.btn_AddEquipment.Text = "Add Equipment";
            this.btn_AddEquipment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddEquipment.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddEquipment.UseVisualStyleBackColor = false;
            this.btn_AddEquipment.Click += new System.EventHandler(this.btn_AddEquipment_Click);
            // 
            // btn_Inventory
            // 
            this.btn_Inventory.BackColor = System.Drawing.Color.Transparent;
            this.btn_Inventory.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Inventory.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Inventory.BorderRadius = 0;
            this.btn_Inventory.BorderSize = 0;
            this.btn_Inventory.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Inventory.FlatAppearance.BorderSize = 0;
            this.btn_Inventory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Inventory.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Inventory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Inventory.Image = global::ILAGAN_Management_System.Properties.Resources.iconInventory_removebg_preview;
            this.btn_Inventory.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Inventory.Location = new System.Drawing.Point(0, 420);
            this.btn_Inventory.Name = "btn_Inventory";
            this.btn_Inventory.Padding = new System.Windows.Forms.Padding(0, 0, 70, 0);
            this.btn_Inventory.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_Inventory.Size = new System.Drawing.Size(223, 35);
            this.btn_Inventory.TabIndex = 22;
            this.btn_Inventory.Text = "Inventory";
            this.btn_Inventory.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Inventory.UseVisualStyleBackColor = false;
            this.btn_Inventory.Click += new System.EventHandler(this.btn_Inventory_Click_1);
            // 
            // panelTransactionSubMenu
            // 
            this.panelTransactionSubMenu.AutoSize = true;
            this.panelTransactionSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelTransactionSubMenu.Controls.Add(this.btn_InstallmentPayment);
            this.panelTransactionSubMenu.Controls.Add(this.btn_Payment);
            this.panelTransactionSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTransactionSubMenu.ForeColor = System.Drawing.Color.Gray;
            this.panelTransactionSubMenu.Location = new System.Drawing.Point(0, 350);
            this.panelTransactionSubMenu.Name = "panelTransactionSubMenu";
            this.panelTransactionSubMenu.Size = new System.Drawing.Size(223, 70);
            this.panelTransactionSubMenu.TabIndex = 17;
            // 
            // btn_InstallmentPayment
            // 
            this.btn_InstallmentPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_InstallmentPayment.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_InstallmentPayment.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_InstallmentPayment.BorderRadius = 0;
            this.btn_InstallmentPayment.BorderSize = 0;
            this.btn_InstallmentPayment.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_InstallmentPayment.FlatAppearance.BorderSize = 0;
            this.btn_InstallmentPayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InstallmentPayment.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InstallmentPayment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_InstallmentPayment.Location = new System.Drawing.Point(0, 35);
            this.btn_InstallmentPayment.Name = "btn_InstallmentPayment";
            this.btn_InstallmentPayment.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_InstallmentPayment.Size = new System.Drawing.Size(223, 35);
            this.btn_InstallmentPayment.TabIndex = 15;
            this.btn_InstallmentPayment.Text = "Installment Payment";
            this.btn_InstallmentPayment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_InstallmentPayment.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_InstallmentPayment.UseVisualStyleBackColor = false;
            this.btn_InstallmentPayment.Click += new System.EventHandler(this.btn_InstallmentPayment_Click_1);
            // 
            // btn_Payment
            // 
            this.btn_Payment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Payment.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Payment.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Payment.BorderRadius = 0;
            this.btn_Payment.BorderSize = 0;
            this.btn_Payment.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Payment.FlatAppearance.BorderSize = 0;
            this.btn_Payment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Payment.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Payment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Payment.Location = new System.Drawing.Point(0, 0);
            this.btn_Payment.Name = "btn_Payment";
            this.btn_Payment.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_Payment.Size = new System.Drawing.Size(223, 35);
            this.btn_Payment.TabIndex = 14;
            this.btn_Payment.Text = "Payment";
            this.btn_Payment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Payment.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Payment.UseVisualStyleBackColor = false;
            this.btn_Payment.Click += new System.EventHandler(this.btn_Payment_Click);
            // 
            // btn_Transaction
            // 
            this.btn_Transaction.BackColor = System.Drawing.Color.Transparent;
            this.btn_Transaction.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Transaction.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Transaction.BorderRadius = 0;
            this.btn_Transaction.BorderSize = 0;
            this.btn_Transaction.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Transaction.FlatAppearance.BorderSize = 0;
            this.btn_Transaction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Transaction.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Transaction.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Transaction.Image = global::ILAGAN_Management_System.Properties.Resources.iconPayment_removebg_preview__1_;
            this.btn_Transaction.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Transaction.Location = new System.Drawing.Point(0, 315);
            this.btn_Transaction.Name = "btn_Transaction";
            this.btn_Transaction.Padding = new System.Windows.Forms.Padding(0, 0, 55, 0);
            this.btn_Transaction.Size = new System.Drawing.Size(223, 35);
            this.btn_Transaction.TabIndex = 16;
            this.btn_Transaction.Text = "Transaction";
            this.btn_Transaction.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Transaction.UseVisualStyleBackColor = false;
            this.btn_Transaction.Click += new System.EventHandler(this.btn_Transaction_Click);
            // 
            // panelServiceSubMenu
            // 
            this.panelServiceSubMenu.AutoSize = true;
            this.panelServiceSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelServiceSubMenu.Controls.Add(this.btn_Package);
            this.panelServiceSubMenu.Controls.Add(this.btn_ServiceRequest);
            this.panelServiceSubMenu.Controls.Add(this.btn_AddClient);
            this.panelServiceSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelServiceSubMenu.ForeColor = System.Drawing.Color.Gray;
            this.panelServiceSubMenu.Location = new System.Drawing.Point(0, 210);
            this.panelServiceSubMenu.Name = "panelServiceSubMenu";
            this.panelServiceSubMenu.Size = new System.Drawing.Size(223, 105);
            this.panelServiceSubMenu.TabIndex = 15;
            // 
            // btn_Package
            // 
            this.btn_Package.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Package.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Package.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Package.BorderRadius = 0;
            this.btn_Package.BorderSize = 0;
            this.btn_Package.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Package.FlatAppearance.BorderSize = 0;
            this.btn_Package.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Package.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Package.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Package.Location = new System.Drawing.Point(0, 70);
            this.btn_Package.Name = "btn_Package";
            this.btn_Package.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_Package.Size = new System.Drawing.Size(223, 35);
            this.btn_Package.TabIndex = 15;
            this.btn_Package.Text = "Create Package";
            this.btn_Package.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Package.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Package.UseVisualStyleBackColor = false;
            this.btn_Package.Click += new System.EventHandler(this.btn_Package_Click);
            // 
            // btn_ServiceRequest
            // 
            this.btn_ServiceRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceRequest.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceRequest.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_ServiceRequest.BorderRadius = 0;
            this.btn_ServiceRequest.BorderSize = 0;
            this.btn_ServiceRequest.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_ServiceRequest.FlatAppearance.BorderSize = 0;
            this.btn_ServiceRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ServiceRequest.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ServiceRequest.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceRequest.Location = new System.Drawing.Point(0, 35);
            this.btn_ServiceRequest.Name = "btn_ServiceRequest";
            this.btn_ServiceRequest.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_ServiceRequest.Size = new System.Drawing.Size(223, 35);
            this.btn_ServiceRequest.TabIndex = 14;
            this.btn_ServiceRequest.Text = "Service Request";
            this.btn_ServiceRequest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ServiceRequest.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceRequest.UseVisualStyleBackColor = false;
            this.btn_ServiceRequest.Click += new System.EventHandler(this.btn_ServiceRequest_Click);
            // 
            // btn_AddClient
            // 
            this.btn_AddClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddClient.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddClient.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_AddClient.BorderRadius = 0;
            this.btn_AddClient.BorderSize = 0;
            this.btn_AddClient.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_AddClient.FlatAppearance.BorderSize = 0;
            this.btn_AddClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AddClient.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddClient.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddClient.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddClient.Location = new System.Drawing.Point(0, 0);
            this.btn_AddClient.Name = "btn_AddClient";
            this.btn_AddClient.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_AddClient.Size = new System.Drawing.Size(223, 35);
            this.btn_AddClient.TabIndex = 13;
            this.btn_AddClient.Text = "Add Client ";
            this.btn_AddClient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddClient.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddClient.UseVisualStyleBackColor = false;
            this.btn_AddClient.Click += new System.EventHandler(this.btn_AddClient_Click);
            // 
            // btn_Service
            // 
            this.btn_Service.BackColor = System.Drawing.Color.Transparent;
            this.btn_Service.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Service.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Service.BorderRadius = 0;
            this.btn_Service.BorderSize = 0;
            this.btn_Service.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Service.FlatAppearance.BorderSize = 0;
            this.btn_Service.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Service.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Service.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Service.Image = global::ILAGAN_Management_System.Properties.Resources.iconService_removebg_preview__1_;
            this.btn_Service.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Service.Location = new System.Drawing.Point(0, 175);
            this.btn_Service.Name = "btn_Service";
            this.btn_Service.Padding = new System.Windows.Forms.Padding(0, 0, 85, 0);
            this.btn_Service.Size = new System.Drawing.Size(223, 35);
            this.btn_Service.TabIndex = 14;
            this.btn_Service.Text = "Service";
            this.btn_Service.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Service.UseVisualStyleBackColor = false;
            this.btn_Service.Click += new System.EventHandler(this.btn_Service_Click);
            // 
            // panelUserSubmenu
            // 
            this.panelUserSubmenu.AutoSize = true;
            this.panelUserSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelUserSubmenu.Controls.Add(this.btn_Permission);
            this.panelUserSubmenu.Controls.Add(this.btn_UserLog);
            this.panelUserSubmenu.Controls.Add(this.btn_AddUser);
            this.panelUserSubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelUserSubmenu.ForeColor = System.Drawing.Color.Gray;
            this.panelUserSubmenu.Location = new System.Drawing.Point(0, 70);
            this.panelUserSubmenu.Name = "panelUserSubmenu";
            this.panelUserSubmenu.Size = new System.Drawing.Size(223, 105);
            this.panelUserSubmenu.TabIndex = 12;
            // 
            // btn_Permission
            // 
            this.btn_Permission.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Permission.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_Permission.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Permission.BorderRadius = 0;
            this.btn_Permission.BorderSize = 0;
            this.btn_Permission.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Permission.FlatAppearance.BorderSize = 0;
            this.btn_Permission.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Permission.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Permission.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Permission.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Permission.Location = new System.Drawing.Point(0, 70);
            this.btn_Permission.Name = "btn_Permission";
            this.btn_Permission.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_Permission.Size = new System.Drawing.Size(223, 35);
            this.btn_Permission.TabIndex = 14;
            this.btn_Permission.Text = "Permissions";
            this.btn_Permission.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Permission.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Permission.UseVisualStyleBackColor = false;
            this.btn_Permission.Click += new System.EventHandler(this.btn_Permission_Click);
            // 
            // btn_UserLog
            // 
            this.btn_UserLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_UserLog.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_UserLog.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_UserLog.BorderRadius = 0;
            this.btn_UserLog.BorderSize = 0;
            this.btn_UserLog.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_UserLog.FlatAppearance.BorderSize = 0;
            this.btn_UserLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UserLog.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_UserLog.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_UserLog.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_UserLog.Location = new System.Drawing.Point(0, 35);
            this.btn_UserLog.Name = "btn_UserLog";
            this.btn_UserLog.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_UserLog.Size = new System.Drawing.Size(223, 35);
            this.btn_UserLog.TabIndex = 13;
            this.btn_UserLog.Text = "User Log";
            this.btn_UserLog.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_UserLog.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_UserLog.UseVisualStyleBackColor = false;
            this.btn_UserLog.Click += new System.EventHandler(this.btn_UserLog_Click);
            // 
            // btn_AddUser
            // 
            this.btn_AddUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddUser.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddUser.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_AddUser.BorderRadius = 0;
            this.btn_AddUser.BorderSize = 0;
            this.btn_AddUser.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_AddUser.FlatAppearance.BorderSize = 0;
            this.btn_AddUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AddUser.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddUser.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddUser.Location = new System.Drawing.Point(0, 0);
            this.btn_AddUser.Name = "btn_AddUser";
            this.btn_AddUser.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_AddUser.Size = new System.Drawing.Size(223, 35);
            this.btn_AddUser.TabIndex = 12;
            this.btn_AddUser.Text = "Add User";
            this.btn_AddUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddUser.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddUser.UseVisualStyleBackColor = false;
            this.btn_AddUser.Click += new System.EventHandler(this.btn_AddUser_Click);
            // 
            // btn_User
            // 
            this.btn_User.BackColor = System.Drawing.Color.Transparent;
            this.btn_User.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_User.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_User.BorderRadius = 0;
            this.btn_User.BorderSize = 0;
            this.btn_User.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_User.FlatAppearance.BorderSize = 0;
            this.btn_User.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_User.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_User.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_User.Image = global::ILAGAN_Management_System.Properties.Resources.iconUser_removebg_preview__2_;
            this.btn_User.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_User.Location = new System.Drawing.Point(0, 35);
            this.btn_User.Name = "btn_User";
            this.btn_User.Padding = new System.Windows.Forms.Padding(0, 0, 95, 0);
            this.btn_User.Size = new System.Drawing.Size(223, 35);
            this.btn_User.TabIndex = 11;
            this.btn_User.Text = "User";
            this.btn_User.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_User.UseVisualStyleBackColor = false;
            this.btn_User.Click += new System.EventHandler(this.btn_User_Click);
            // 
            // btn_Home
            // 
            this.btn_Home.BackColor = System.Drawing.Color.Transparent;
            this.btn_Home.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Home.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Home.BorderRadius = 0;
            this.btn_Home.BorderSize = 0;
            this.btn_Home.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Home.FlatAppearance.BorderSize = 0;
            this.btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Home.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Home.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Home.Image = global::ILAGAN_Management_System.Properties.Resources.iconHome_removebg_preview__1_;
            this.btn_Home.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Home.Location = new System.Drawing.Point(0, 0);
            this.btn_Home.Name = "btn_Home";
            this.btn_Home.Padding = new System.Windows.Forms.Padding(0, 0, 90, 0);
            this.btn_Home.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_Home.Size = new System.Drawing.Size(223, 35);
            this.btn_Home.TabIndex = 11;
            this.btn_Home.Text = "Home";
            this.btn_Home.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Home.UseVisualStyleBackColor = false;
            this.btn_Home.Click += new System.EventHandler(this.btn_Home_Click);
            // 
            // Complete_Service
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.RoyalBlue;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            this.Complete_Service.DefaultCellStyle = dataGridViewCellStyle2;
            this.Complete_Service.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Complete_Service.HeaderText = "Complete";
            this.Complete_Service.Name = "Complete_Service";
            this.Complete_Service.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Complete_Service.Text = "Complete";
            this.Complete_Service.UseColumnTextForButtonValue = true;
            this.Complete_Service.Visible = false;
            // 
            // ServiceRequest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 662);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Name = "ServiceRequest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ServiceRequest";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ServiceRequestRecords)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panelSettingsSubMenu.ResumeLayout(false);
            this.panelReportsSubMenu.ResumeLayout(false);
            this.panelInventorySubMenu.ResumeLayout(false);
            this.panelTransactionSubMenu.ResumeLayout(false);
            this.panelServiceSubMenu.ResumeLayout(false);
            this.panelUserSubmenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private RoundedButton btnLogout;
        private System.Windows.Forms.Label SystemNamelbl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtsearch;
        private RoundedButton btn_EditUser;
        private RoundedButton btnNewUser;
        private System.Windows.Forms.DataGridView dgv_ServiceRequestRecords;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelSettingsSubMenu;
        private RoundedButton btn_ChangePassword;
        private RoundedButton btn_AccountDetails;
        private RoundedButton btn_EmployeeList;
        private RoundedButton btn_Settings;
        private System.Windows.Forms.Panel panelReportsSubMenu;
        private RoundedButton btn_EquipmentNarrative;
        private RoundedButton btn_Sales;
        private RoundedButton btn_InventoryMasterList;
        private RoundedButton btn_EquipmentReleaseLog;
        private RoundedButton btn_ServiceHistory;
        private RoundedButton btn_Reports;
        private System.Windows.Forms.Panel panelInventorySubMenu;
        private RoundedButton btn_AddEquipment;
        private RoundedButton btn_Inventory;
        private System.Windows.Forms.Panel panelTransactionSubMenu;
        private RoundedButton btn_InstallmentPayment;
        private RoundedButton btn_Payment;
        private RoundedButton btn_Transaction;
        private System.Windows.Forms.Panel panelServiceSubMenu;
        private RoundedButton btn_Package;
        private RoundedButton btn_ServiceRequest;
        private RoundedButton btn_AddClient;
        private RoundedButton btn_Service;
        private System.Windows.Forms.Panel panelUserSubmenu;
        private RoundedButton btn_Permission;
        private RoundedButton btn_UserLog;
        private RoundedButton btn_AddUser;
        private RoundedButton btn_User;
        private RoundedButton btn_Home;
        private System.Windows.Forms.DataGridViewButtonColumn Complete_Service;
    }
}
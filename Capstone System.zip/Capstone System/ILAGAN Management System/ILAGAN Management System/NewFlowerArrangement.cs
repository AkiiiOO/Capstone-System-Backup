﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;


namespace ILAGAN_Management_System
{
    public partial class NewFlowerArrangement : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public NewFlowerArrangement()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadFlowerArrangementTypes();
        }

        private void btn_Upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                picb_FlowerArrangement.Image = Image.FromFile(filePath);
            }
        }
        private void LoadFlowerArrangementTypes()
        {
            // Create a DataTable to hold the Flower Arrangement types
            string query = "SELECT ArrangementTypeID, ArrangementTypeName FROM FlowerArrangementsType";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                try
                {
                    db.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable dtFlowerArrangementTypes = new DataTable();
                        dtFlowerArrangementTypes.Load(reader);
                        cmb_FlowerArrangementType.DataSource = dtFlowerArrangementTypes;
                        cmb_FlowerArrangementType.DisplayMember = "ArrangementTypeName"; // The field to display
                        cmb_FlowerArrangementType.ValueMember = "ArrangementTypeID";
                        cmb_FlowerArrangementType.SelectedIndex = -1;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error fetching Flower Arrangement Types: " + ex.Message);
                }
                finally
                {
                    db.Close(); // Ensure the database connection is closed
                }
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            // Check if all fields are filled
            if (cmb_FlowerArrangementType.SelectedIndex == -1 || string.IsNullOrEmpty(txt_FlowerArrangementName.Text) || string.IsNullOrEmpty(txt_FlowerArrangementPrice.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                // Get values from form controls
                int flowerArrangementTypeId = (int)cmb_FlowerArrangementType.SelectedValue;
                string flowerArrangementName = txt_FlowerArrangementName.Text;
                decimal flowerArrangementPrice = decimal.Parse(txt_FlowerArrangementPrice.Text);

                // Convert image to byte array if an image is selected
                byte[] flowerArrangementImage = null;
                if (picb_FlowerArrangement.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        picb_FlowerArrangement.Image.Save(ms, picb_FlowerArrangement.Image.RawFormat);
                        flowerArrangementImage = ms.ToArray();
                    }
                }

                // Prepare the SQL Insert query
                string insertQuery = "INSERT INTO FlowerArrangements (ArrangementTypeID, ArrangementImage, ArrangementName, Price) " +
                                     "VALUES (@ArrangementTypeID, @ArrangementImage, @ArrangementName, @Price)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@ArrangementTypeID", flowerArrangementTypeId);
                    command.Parameters.AddWithValue("@ArrangementImage", flowerArrangementImage ?? (object)DBNull.Value); // Use DBNull if no image is provided
                    command.Parameters.AddWithValue("@ArrangementName", flowerArrangementName);
                    command.Parameters.AddWithValue("@Price", flowerArrangementPrice);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Flower Arrangement inserted successfully.");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Error inserting Flower Arrangement.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}

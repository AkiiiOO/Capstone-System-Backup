﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class SelectEquipments : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public List<Equipment> SelectedEquipments { get; set; }

        public SelectEquipments()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadEquipment();
            SelectedEquipments = new List<Equipment>();
        }
        private void LoadEquipment()
        {
            try
            {
                db.Open();
                string query = @"SELECT E.EquipmentID, E.EquipmentName, E.EquipmentType, E.Quantity, 
                                EQ.EquipmentQualityID, EQ.Quality AS EquipmentQuality, 
                                EC.EquipmentConditionID, EC.Condition AS EquipmentCondition,
                                E.DamageNote
                         FROM Equipment E
                         JOIN EquipmentQuality EQ ON E.EquipmentQualityID = EQ.EquipmentQualityID
                         JOIN EquipmentCondition EC ON E.EquipmentConditionID = EC.EquipmentConditionID";

                SqlCommand command = new SqlCommand(query, db);
                SqlDataAdapter dt = new SqlDataAdapter(command);

                DataTable equipmentTable = new DataTable();
                dt.Fill(equipmentTable);
                dgv_EquipmentsRecords.DataSource = equipmentTable;

                // Rename the columns to be more user-friendly
                dgv_EquipmentsRecords.Columns["EquipmentID"].Visible = false;  // Hide the EquipmentID column
                dgv_EquipmentsRecords.Columns["EquipmentName"].HeaderText = "Equipment Name";
                dgv_EquipmentsRecords.Columns["EquipmentName"].ReadOnly = true;
                dgv_EquipmentsRecords.Columns["EquipmentType"].HeaderText = "Equipment Type";
                dgv_EquipmentsRecords.Columns["EquipmentType"].ReadOnly = true;
                dgv_EquipmentsRecords.Columns["Quantity"].HeaderText = "Quantity Available";
                dgv_EquipmentsRecords.Columns["Quantity"].ReadOnly = true;
                dgv_EquipmentsRecords.Columns["EquipmentQuality"].HeaderText = "Equipment Quality";
                dgv_EquipmentsRecords.Columns["EquipmentQuality"].ReadOnly = true;
                dgv_EquipmentsRecords.Columns["EquipmentCondition"].HeaderText = "Equipment Condition";
                dgv_EquipmentsRecords.Columns["EquipmentCondition"].ReadOnly = true;
                dgv_EquipmentsRecords.Columns["DamageNote"].HeaderText = "Damage Note";
                dgv_EquipmentsRecords.Columns["DamageNote"].ReadOnly = true;


                // Make the 'Select' column visible if you have one for selection
                dgv_EquipmentsRecords.Columns["EquipmentQualityID"].Visible = false;
                dgv_EquipmentsRecords.Columns["EquipmentConditionID"].Visible = false;
                dgv_EquipmentsRecords.Columns["SelectColumn"].Visible = true;
                dgv_EquipmentsRecords.Columns["txt_Quantity"].Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading equipment: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }

        private void btn_Select_Click(object sender, EventArgs e)
        {
            SelectedEquipments.Clear(); 
            
            foreach (DataGridViewRow row in dgv_EquipmentsRecords.Rows)
            {
                if (Convert.ToBoolean(row.Cells["SelectColumn"].Value)) // Check if selected
                {
                    if (row.Cells["txt_Quantity"].Value == null || string.IsNullOrEmpty(row.Cells["txt_Quantity"].Value.ToString()))
                    {
                        MessageBox.Show("Quantity is required for selected equipment.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    int quantity;
                    if (!int.TryParse(row.Cells["txt_Quantity"].Value.ToString(), out quantity) || quantity <= 0)
                    {
                        MessageBox.Show("Quantity must be a valid number greater than 0.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }


                    int equipmentQualityID = Convert.ToInt32(row.Cells["EquipmentQualityID"].Value);
                    int equipmentConditionID = Convert.ToInt32(row.Cells["EquipmentConditionID"].Value); 
                    string equipmentName = row.Cells["EquipmentName"].Value.ToString();
                    string equipmentType = row.Cells["EquipmentType"].Value.ToString();
                    string equipmentQuality = row.Cells["EquipmentQuality"].Value.ToString();
                    string equipmentCondition = row.Cells["EquipmentCondition"].Value.ToString();
                    string damageNote = row.Cells["DamageNote"].Value.ToString();
                    int availableQuantity = Convert.ToInt32(row.Cells["Quantity"].Value);


                    if (quantity > availableQuantity)
                    {
                        MessageBox.Show("You can only select up to " + availableQuantity + " of " + equipmentName, "Quantity Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    SelectedEquipments.Add(new Equipment
                    {
                        EquipmentID = Convert.ToInt32(row.Cells["EquipmentID"].Value),
                        EquipmentName = equipmentName,
                        EquipmentType = equipmentType,
                        EquipmentQuality = equipmentQuality,
                        EquipmentQualityID = equipmentQualityID, 
                        EquipmentCondition = equipmentCondition,
                        EquipmentConditionID = equipmentConditionID,
                        DamageNote = damageNote,
                        Quantity = quantity
                    });
                }
            }

            if (SelectedEquipments.Count > 0)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Please select at least one equipment.");
            }
        }
        public class Equipment
        {
            public int EquipmentID { get; set; }
            public int EquipmentQualityID { get; set; }
            public int EquipmentConditionID { get; set; }
            public string EquipmentName { get; set; }
            public string EquipmentType { get; set; }
            public string EquipmentQuality { get; set; }
            public string EquipmentCondition { get; set; }
            public string DamageNote { get; set; } 
            public int Quantity { get; set; }

        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            string searchText = txt_search.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadEquipment(); // Load all equipment records when search text is empty
                return;
            }

            string query = @"SELECT EquipmentID, EquipmentName, EquipmentType, EquipmentQuality, EquipmentCondition, Quantity, DamageNote 
                     FROM Equipment 
                     WHERE EquipmentName LIKE @SearchText 
                        OR EquipmentType LIKE @SearchText
                        OR EquipmentQuality LIKE @SearchText
                        OR EquipmentCondition LIKE @SearchText";

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, db))
                {
                    cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dgv_EquipmentsRecords.DataSource = dt;
                        }
                        else
                        {
                            dgv_EquipmentsRecords.DataSource = null;
                            MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}

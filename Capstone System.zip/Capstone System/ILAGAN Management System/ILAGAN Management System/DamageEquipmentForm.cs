﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class DamageEquipmentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        private List<DataGridViewRow> selectedRows;
        int serviceRequestID;
        string serviceLocation;

        public DamageEquipmentForm(List<DataGridViewRow> selectedRows)
        {
            InitializeComponent();
            db = y.GetConnection();
            this.selectedRows = selectedRows;
            PopulateRelease();
            LoadEmployees();
        }
        private void PopulateRelease()
        {
            if (selectedRows.Count == 1)
            {
                var row = selectedRows[0];

                // Extract the Service Location value
                serviceRequestID = Convert.ToInt32(row.Cells["ServiceRequestID"].Value);
                serviceLocation = row.Cells["Service Location"].Value.ToString();

                lbl_Location.Text = serviceLocation;

                LoadReleasedEquipment();

            }
            else
            {
                MessageBox.Show("Please select one service request.");
            }
        }
        private void LoadReleasedEquipment()
        {
            try
            {
                db.Open();

                // Query to fetch released equipment associated with the selected service request
                string query = @"
                SELECT 
                    er.EquipmentReleaseID,
                    e.EquipmentID,
                    e.EquipmentName, 
                    e.EquipmentType, 
                    er.Quantity
                FROM EquipmentRelease er
                JOIN Equipment e ON er.EquipmentID = e.EquipmentID
                WHERE er.ServiceRequestID = @ServiceRequestID";

                SqlCommand cmd = new SqlCommand(query, db);
                cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Rename columns for display
                dataTable.Columns["EquipmentName"].ColumnName = "Equipment Name";
                dataTable.Columns["EquipmentType"].ColumnName = "Type";
                dataTable.Columns["Quantity"].ColumnName = "Quantity";


                // Bind the equipment data to the DataGridView
                dgv_EquipmentsReturnDisplay.DataSource = dataTable;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentReleaseID"].Visible = false;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentID"].Visible = false;
                dgv_EquipmentsReturnDisplay.Columns["SelectColumn"].Visible = true;
                dgv_EquipmentsReturnDisplay.Columns["txt_Quantity"].Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading equipment: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }
        private void LoadEmployees()
        {
            try
            {
                // Open the database connection
                db.Open();

                // Query to select EmployeeID, FirstName, and LastName from Employees table
                string query = "SELECT EmployeeID, FirstName, LastName FROM Employees";

                SqlCommand cmd = new SqlCommand(query, db);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataTable.Columns.Add("FullName", typeof(string), "FirstName + ' ' + LastName");

                // Bind the data to the ComboBox
                cmb_Employees.DataSource = dataTable;
                cmb_Employees.DisplayMember = "FullName";
                cmb_Employees.ValueMember = "EmployeeID";

                cmb_Employees.SelectedIndex = -1;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading employees: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }

        private void btn_SubmitReport_Click(object sender, EventArgs e)
        {
            // Assuming the user selects multiple rows in the DataGridView
            if (dgv_EquipmentsReturnDisplay.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select at least one equipment.");
                return;
            }


            // Collect details from the form (for the main damage report)
            string location = lbl_Location.Text;
            string damageDescription = txt_DamageDescription.Text;
            string actionTaken = txt_ActionTaken.Text;
            string reportedBy = cmb_Employees.SelectedValue.ToString();

            try
            {
                db.Open();

                // Insert the main damage report record
                string insertDamageReportQuery = @"
                INSERT INTO DamageReport 
                (ServiceRequestID, Location, DamageDescription, ActionTaken, ReportedBy)
                OUTPUT INSERTED.DamageReportID
                VALUES (@ServiceRequestID, @Location, @DamageDescription, @ActionTaken, @ReportedBy)";

                SqlCommand cmd = new SqlCommand(insertDamageReportQuery, db);
                cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID); // Assuming serviceRequestID is available
                cmd.Parameters.AddWithValue("@Location", location);
                cmd.Parameters.AddWithValue("@DamageDescription", damageDescription);
                cmd.Parameters.AddWithValue("@ActionTaken", actionTaken);
                cmd.Parameters.AddWithValue("@ReportedBy", reportedBy);

                int damageReportID = (int)cmd.ExecuteScalar();  // Get the inserted DamageReportID

                // Now insert records into DamageReportEquipment for each selected equipment
                foreach (DataGridViewRow row in dgv_EquipmentsReturnDisplay.SelectedRows)
                {
                    if (row.Cells["txt_Quantity"].Value == null || string.IsNullOrEmpty(row.Cells["txt_Quantity"].Value.ToString()))
                    {
                        MessageBox.Show("Quantity is required to report damage.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    int quantityequip;
                    if (!int.TryParse(row.Cells["txt_Quantity"].Value.ToString(), out quantityequip) || quantityequip <= 0)
                    {
                        MessageBox.Show("Quantity must be a valid number greater than 0.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    int equipmentID = Convert.ToInt32(row.Cells["EquipmentID"].Value);
                    int quantity = Convert.ToInt32(row.Cells["Quantity"].Value);  // Assuming there's a quantity column
                    string equipname = row.Cells["Equipment Name"].Value.ToString();
                    if (quantityequip > quantity)
                    {
                        MessageBox.Show("You can only select up to " + quantityequip + " of " + equipname, "Quantity Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    string insertDamageReportEquipmentQuery = @"
                    INSERT INTO DamageReportEquipment
                    (DamageReportID, EquipmentID, Quantity)
                    VALUES (@DamageReportID, @EquipmentID, @Quantity)";

                    SqlCommand cmdEquipment = new SqlCommand(insertDamageReportEquipmentQuery, db);
                    cmdEquipment.Parameters.AddWithValue("@DamageReportID", damageReportID);
                    cmdEquipment.Parameters.AddWithValue("@EquipmentID", equipmentID);
                    cmdEquipment.Parameters.AddWithValue("@Quantity", quantity);

                    cmdEquipment.ExecuteNonQuery();
                }

                MessageBox.Show("Damage report successfully saved for the selected equipment.");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving damage report: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class NewCemeteryForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public NewCemeteryForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadCemeteries();
        }
        private void LoadCemeteries()
        {
            try
            {
                string query = "SELECT CemeteryID, CemeteryName, Location FROM Cemeteries";
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dtCemeteries = new DataTable();
                adapter.Fill(dtCemeteries);

                dgv_CemeteryList.DataSource = dtCemeteries;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Cemeteries: " + ex.Message);
            }
        }


        private void btn_Add_Click(object sender, EventArgs e)
        {
            // Check if all fields are filled
            if (string.IsNullOrEmpty(txt_CemeteryName.Text) || string.IsNullOrEmpty(txt_Location.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                // Get values from form controls
                string cemeteryName = txt_CemeteryName.Text;
                string location = txt_Location.Text;
                string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

                // Prepare the SQL Insert query
                string insertQuery = "INSERT INTO Cemeteries (CemeteryName, Location, CreatedBy) " +
                                     "VALUES (@CemeteryName, @Location, @CreatedBy)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@CemeteryName", cemeteryName);
                    command.Parameters.AddWithValue("@Location", location);
                    command.Parameters.AddWithValue("@CreatedBy", createdBy);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Cemetery added successfully.");
                        LoadCemeteries();
                    }
                    else
                    {
                        MessageBox.Show("Error adding Cemetery.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (dgv_CemeteryList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a Cemetery to update.");
                return;
            }

            if (string.IsNullOrEmpty(txt_CemeteryName.Text) || string.IsNullOrEmpty(txt_Location.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                int cemeteryId = Convert.ToInt32(dgv_CemeteryList.SelectedRows[0].Cells["CemeteryID"].Value);
                string cemeteryName = txt_CemeteryName.Text;
                string location = txt_Location.Text;
                string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

                string updateQuery = "UPDATE Cemeteries SET CemeteryName = @CemeteryName, Location = @Location, CreatedBy = @CreatedBy WHERE CemeteryID = @CemeteryID";

                using (SqlCommand command = new SqlCommand(updateQuery, db))
                {
                    command.Parameters.AddWithValue("@CemeteryName", cemeteryName);
                    command.Parameters.AddWithValue("@Location", location);
                    command.Parameters.AddWithValue("@CreatedBy", createdBy);
                    command.Parameters.AddWithValue("@CemeteryID", cemeteryId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Cemetery updated successfully.");
                        LoadCemeteries();
                    }
                    else
                    {
                        MessageBox.Show("Error updating Cemetery.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (dgv_CemeteryList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a Cemetery to delete.");
                return;
            }

            try
            {
                int cemeteryId = Convert.ToInt32(dgv_CemeteryList.SelectedRows[0].Cells["CemeteryID"].Value);

                string deleteQuery = "DELETE FROM Cemeteries WHERE CemeteryID = @CemeteryID";

                using (SqlCommand command = new SqlCommand(deleteQuery, db))
                {
                    command.Parameters.AddWithValue("@CemeteryID", cemeteryId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Cemetery deleted successfully.");
                        LoadCemeteries();
                    }
                    else
                    {
                        MessageBox.Show("Error deleting Cemetery.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dgv_CemeteryList_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_CemeteryList.Rows[e.RowIndex];
                txt_CemeteryName.Text = row.Cells["CemeteryName"].Value.ToString();
                txt_Location.Text = row.Cells["Location"].Value.ToString();
            }
        }
    }
}

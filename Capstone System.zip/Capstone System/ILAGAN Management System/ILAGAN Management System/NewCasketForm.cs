﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace ILAGAN_Management_System
{
    public partial class NewCasketForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public NewCasketForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadCasketTypes();
            LoadCasketList();
        }

        private void btn_Upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                picb_Casket.Image = Image.FromFile(filePath);
            }
        }
        private void LoadCasketTypes()
        {
            // Create a DataTable to hold the Casket types
            

            // SQL query to select the Casket types
            string query = "SELECT CasketTypeID, CasketTypeName FROM CasketType";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                try
                {
                    db.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        DataTable dtCasketTypes = new DataTable();
                        dtCasketTypes.Load(reader);
                        // Bind the ComboBox to the DataTable
                        cmb_CasketType.DataSource = dtCasketTypes;
                        cmb_CasketType.DisplayMember = "CasketTypeName";  // The field to display
                        cmb_CasketType.ValueMember = "CasketTypeID";
                        cmb_CasketType.SelectedIndex = -1;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error fetching Casket Types: " + ex.Message);
                }
                finally
                {
                    db.Close(); // Ensure the database connection is closed
                }
            }  
        }
        private void LoadCasketList()
        {
            try
            {
                string query = "SELECT CasketID, CasketName, CasketTypeName, Price , CasketImage FROM Casket " +
                               "JOIN CasketType ON Casket.CasketTypeID = CasketType.CasketTypeID";
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dtCasketList = new DataTable();
                adapter.Fill(dtCasketList);

                dgv_CasketList.DataSource = dtCasketList;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading casket list: " + ex.Message);
            }
        }


        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (cmb_CasketType.SelectedIndex == -1 || string.IsNullOrEmpty(txt_CasketName.Text) || string.IsNullOrEmpty(txt_CasketPrice.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                int casketTypeId = (int)cmb_CasketType.SelectedValue;
                string casketName = txt_CasketName.Text;
                decimal casketPrice = decimal.Parse(txt_CasketPrice.Text);

                byte[] casketImage = null;
                if (picb_Casket.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        picb_Casket.Image.Save(ms, picb_Casket.Image.RawFormat);
                        casketImage = ms.ToArray();
                    }
                }

                string insertQuery = "INSERT INTO Casket (CasketTypeID, CasketImage, CasketName, Price) " +
                                     "VALUES (@CasketTypeID, @CasketImage, @CasketName, @Price)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@CasketTypeID", casketTypeId);
                    command.Parameters.AddWithValue("@CasketImage", casketImage ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@CasketName", casketName);
                    command.Parameters.AddWithValue("@Price", casketPrice);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Casket inserted successfully.");
                        LoadCasketList(); // Refresh the casket list
                    }
                    else
                    {
                        MessageBox.Show("Error inserting Casket.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (dgv_CasketList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a casket to update.");
                return;
            }

            if (string.IsNullOrEmpty(txt_CasketName.Text) || string.IsNullOrEmpty(txt_CasketPrice.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                int casketId = Convert.ToInt32(dgv_CasketList.SelectedRows[0].Cells["CasketID"].Value);
                string casketName = txt_CasketName.Text;
                decimal casketPrice = decimal.Parse(txt_CasketPrice.Text);
                int casketTypeId = (int)cmb_CasketType.SelectedValue;

                string updateQuery = "UPDATE Casket SET CasketName = @CasketName, CasketTypeID = @CasketTypeID, " +
                                     "Price = @Price WHERE CasketID = @CasketID";

                using (SqlCommand command = new SqlCommand(updateQuery, db))
                {
                    command.Parameters.AddWithValue("@CasketName", casketName);
                    command.Parameters.AddWithValue("@CasketTypeID", casketTypeId);
                    command.Parameters.AddWithValue("@Price", casketPrice);
                    command.Parameters.AddWithValue("@CasketID", casketId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Casket updated successfully.");
                        LoadCasketList(); // Refresh the casket list
                    }
                    else
                    {
                        MessageBox.Show("Error updating Casket.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (dgv_CasketList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a casket to delete.");
                return;
            }

            try
            {
                int casketId = Convert.ToInt32(dgv_CasketList.SelectedRows[0].Cells["CasketID"].Value);

                string deleteQuery = "DELETE FROM Casket WHERE CasketID = @CasketID";

                using (SqlCommand command = new SqlCommand(deleteQuery, db))
                {
                    command.Parameters.AddWithValue("@CasketID", casketId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Casket deleted successfully.");
                        LoadCasketList(); // Refresh the casket list
                    }
                    else
                    {
                        MessageBox.Show("Error deleting Casket.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dgv_CasketList_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_CasketList.Rows[e.RowIndex];
                txt_CasketName.Text = row.Cells["CasketName"].Value.ToString();
                txt_CasketPrice.Text = row.Cells["Price"].Value.ToString();

                string casketTypeName = row.Cells["CasketTypeName"].Value.ToString();
                // Now select the ComboBox item based on the CasketTypeName
                foreach (var item in cmb_CasketType.Items)
                {
                    if (item.ToString() == casketTypeName)
                    {
                        cmb_CasketType.SelectedItem = item;
                        break;
                    }
                }

                // Populate the PictureBox with the Casket Image (if any)
                if (row.Cells["CasketImage"].Value != DBNull.Value)
                {
                    byte[] imageData = (byte[])row.Cells["CasketImage"].Value;
                    using (MemoryStream ms = new MemoryStream(imageData))
                    {
                        picb_Casket.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    picb_Casket.Image = null; // Set to null if no image is present
                }
            }

        }
    }
}

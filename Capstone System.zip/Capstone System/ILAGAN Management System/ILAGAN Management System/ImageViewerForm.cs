﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class ImageViewerForm : Form
    {
        private Image _image;
        private float _zoomFactor = 1.0f;

        public ImageViewerForm(Image image)
        {
            InitializeComponent();
            _image = image;
            picbox_View.SizeMode = PictureBoxSizeMode.Normal;
            this.MouseWheel += ImageViewerForm_MouseWheel;

            FitToImage();
        }

        private void FitToImage()
        {
            if (_image != null)
            {
                float widthFactor = (float)picbox_View.Width / _image.Width;
                float heightFactor = (float)picbox_View.Height / _image.Height;
                _zoomFactor = Math.Min(widthFactor, heightFactor);
            }
        }

        private void ImageViewerForm_MouseWheel(object sender, MouseEventArgs e)
        {
            if (e.Delta > 0)
            {
                _zoomFactor += 0.1f;
            }
            else if (e.Delta < 0)
            {
                _zoomFactor = Math.Max(0.1f, _zoomFactor - 0.1f);
            }

            picbox_View.Invalidate();
        }

        private void Picbox_View_Paint(object sender, PaintEventArgs e)
        {
            if (_image != null)
            {
                int newWidth = (int)(_image.Width * _zoomFactor);
                int newHeight = (int)(_image.Height * _zoomFactor);

                int x = (picbox_View.Width - newWidth) / 2;
                int y = (picbox_View.Height - newHeight) / 2;

                e.Graphics.DrawImage(_image, x, y, newWidth, newHeight);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ReleaseEquipmentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        private List<DataGridViewRow> selectedRows;
        string serviceLocation;
        int serviceRequestID; 

        public ReleaseEquipmentForm(List<DataGridViewRow> selectedRows)
        {
            InitializeComponent();
            db = y.GetConnection();
            this.selectedRows = selectedRows;
            PopulateRelease();
            LoadEmployees();
        }
        private void PopulateRelease()
        {
            if (selectedRows.Count == 1)
            {
                var row = selectedRows[0];

                // Extract the Service Location value
                serviceLocation = row.Cells["Service Location"].Value.ToString();
                serviceRequestID = Convert.ToInt32(row.Cells["ServiceRequestID"].Value);

                // Populate the Service Location field
                lbl_Location.Text = serviceLocation;

                LoadEquipment();

            }
            else
            {
                MessageBox.Show("Please select one service request.");
            }
        }
        private void LoadEquipment()
        {
            try
            {
                db.Open();

                // Query to fetch equipment associated with the selected service request
                string query = @"
                SELECT 
                    srpe.EquipmentName, 
                    srpe.EquipmentType, 
                    srpe.Quantity 
                FROM ServiceRequestsPackageEquipments srpe
                WHERE srpe.ServiceRequestID = @ServiceRequestID";

                SqlCommand cmd = new SqlCommand(query, db);
                cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Bind the equipment data to the DataGridView
                dgv_EquipmentsReleasedisplay.DataSource = dataTable;

                // Optional: Rename columns for display
                dataTable.Columns["EquipmentName"].ColumnName = "Equipment Name";
                dataTable.Columns["EquipmentType"].ColumnName = "Type";
                dataTable.Columns["Quantity"].ColumnName = "Quantity";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading equipment: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }
        private void LoadEmployees()
        {
            try
            {
                // Open the database connection
                db.Open();

                // Query to select EmployeeID, FirstName, and LastName from Employees table
                string query = "SELECT EmployeeID, FirstName, LastName FROM Employees";

                SqlCommand cmd = new SqlCommand(query, db);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataTable.Columns.Add("FullName", typeof(string), "FirstName + ' ' + LastName");

                // Bind the data to the ComboBox
                cmb_Employees.DataSource = dataTable;
                cmb_Employees.DisplayMember = "FullName"; 
                cmb_Employees.ValueMember = "EmployeeID";

                cmb_Employees.SelectedIndex = -1;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading employees: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }



        private void btn_Release_Click(object sender, EventArgs e)
        {
            // Check if an employee is selected
            if (cmb_Employees.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an employee to release the equipment.");
                return;
            }

            // Get the selected employee ID
            int employeeID = Convert.ToInt32(cmb_Employees.SelectedValue);

            try
            {
                db.Open();

                // Loop through the selected equipment from the DataGridView
                foreach (DataGridViewRow row in dgv_EquipmentsReleasedisplay.Rows)
                {
                    if (row.Cells["Equipment Name"].Value != null && row.Cells["Quantity"].Value != null)
                    {
                        string equipmentName = row.Cells["Equipment Name"].Value.ToString();
                        int quantity = Convert.ToInt32(row.Cells["Quantity"].Value);

                        // Get the EquipmentID from the Equipment table based on the Equipment Name
                        string equipmentQuery = "SELECT EquipmentID FROM Equipment WHERE EquipmentName = @EquipmentName";
                        SqlCommand equipmentCmd = new SqlCommand(equipmentQuery, db);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentName", equipmentName);
                        int equipmentID = Convert.ToInt32(equipmentCmd.ExecuteScalar());

                        // Insert a record into EquipmentRelease table
                        string releaseQuery = @"
                    INSERT INTO EquipmentRelease (ServiceRequestID, EquipmentStatusID, EquipmentID, Quantity, ReleaseDate, ReleasedBy)
                    VALUES (@ServiceRequestID, @EquipmentStatusID, @EquipmentID, @Quantity, GETDATE(), @ReleasedBy)";
                        SqlCommand releaseCmd = new SqlCommand(releaseQuery, db);
                        releaseCmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);
                        releaseCmd.Parameters.AddWithValue("@EquipmentStatusID", 3);
                        releaseCmd.Parameters.AddWithValue("@EquipmentID", equipmentID);
                        releaseCmd.Parameters.AddWithValue("@Quantity", quantity);
                        releaseCmd.Parameters.AddWithValue("@ReleasedBy", employeeID);

                        releaseCmd.ExecuteNonQuery();

                        // Optionally: Update the Equipment status to 'Released' or handle equipment availability
                        string updateEquipmentQuery = "UPDATE Equipment SET Quantity = Quantity - @Quantity WHERE EquipmentID = @EquipmentID";
                        SqlCommand updateCmd = new SqlCommand(updateEquipmentQuery, db);
                        updateCmd.Parameters.AddWithValue("@Quantity", quantity);
                        updateCmd.Parameters.AddWithValue("@EquipmentID", equipmentID);
                        updateCmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Equipment has been successfully released.");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error releasing equipment: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class btn_NewClient : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public int SelectedClientID { get; private set; }
        public string SelectedFirstName { get; private set; }
        public string SelectedMiddleName { get; private set; }
        public string SelectedLastName { get; private set; }
        public string SelectedAddress { get; private set; }

        public btn_NewClient()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadAllClients();
        }
        private void LoadAllClients()
        {
            string query = @"SELECT ClientID, FirstName, MiddleName, LastName, Address, Contact_No 
                     FROM Clients";

            SqlCommand cmd = new SqlCommand(query, db);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                adapter.Fill(dt);
                dgv_Client.DataSource = dt; // Bind all client data to the DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void dgv_Client_DoubleClick(object sender, EventArgs e)
        {
            if (dgv_Client.SelectedRows.Count > 0)
            {
   
                DataGridViewRow selectedRow = dgv_Client.SelectedRows[0];
                
                int clientID = Convert.ToInt32(selectedRow.Cells["ClientID"].Value);
                string firstName = selectedRow.Cells["FirstName"].Value.ToString();
                string middleName = selectedRow.Cells["MiddleName"].Value.ToString();
                string lastName = selectedRow.Cells["LastName"].Value.ToString();
                string address = selectedRow.Cells["Address"].Value.ToString();

                SelectedClientID = clientID;
                SelectedFirstName = firstName;
                SelectedMiddleName = middleName;
                SelectedLastName = lastName;
                SelectedAddress = address;

                // Close the form (or perform other necessary actions)
                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                MessageBox.Show("Please select a client.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            string searchText = txt_search.Text.Trim();

            // If the search text is empty, load all clients
            if (string.IsNullOrEmpty(searchText))
            {
                MessageBox.Show("Empty Textbox.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string query = @"SELECT ClientID, FirstName, MiddleName, LastName, Address, Contact_No 
                     FROM Clients 
                     WHERE ClientID LIKE @SearchText
                     OR FirstName LIKE @SearchText 
                     OR MiddleName LIKE @SearchText 
                     OR LastName LIKE @SearchText
                     OR Address LIKE @SearchText";

            SqlCommand cmd = new SqlCommand(query, db);
            cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                adapter.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dgv_Client.DataSource = dt; // Bind results to DataGridView
                }
                else
                {
                    MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgv_Client.DataSource = null; // Clear previous data
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void AddClientForm_ClientAdded(object sender, EventArgs e)
        {
            LoadAllClients();
        }
        private void btn_View_Click(object sender, EventArgs e)
        {
            AddNewClientForm addClientForm = new AddNewClientForm();
            addClientForm.ClientAdded += AddClientForm_ClientAdded;
            addClientForm.ShowDialog();
        }
    }
}

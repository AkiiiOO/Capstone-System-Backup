﻿namespace ILAGAN_Management_System
{
    partial class SelectFlowerArrangement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_FlowerPrice = new System.Windows.Forms.Label();
            this.lbl_FlowerName = new System.Windows.Forms.Label();
            this.las = new System.Windows.Forms.Label();
            this.asd = new System.Windows.Forms.Label();
            this.picbox_FlowerImage = new System.Windows.Forms.PictureBox();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.dgv_FlowerRecords = new System.Windows.Forms.DataGridView();
            this.btnSelect = new ILAGAN_Management_System.RoundedButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_FlowerImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_FlowerRecords)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(836, 68);
            this.panel1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Select Flower Arrangement";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lbl_FlowerPrice
            // 
            this.lbl_FlowerPrice.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_FlowerPrice.AutoSize = true;
            this.lbl_FlowerPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FlowerPrice.Location = new System.Drawing.Point(670, 252);
            this.lbl_FlowerPrice.Name = "lbl_FlowerPrice";
            this.lbl_FlowerPrice.Size = new System.Drawing.Size(75, 15);
            this.lbl_FlowerPrice.TabIndex = 109;
            this.lbl_FlowerPrice.Text = "-----------------";
            // 
            // lbl_FlowerName
            // 
            this.lbl_FlowerName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_FlowerName.AutoSize = true;
            this.lbl_FlowerName.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FlowerName.Location = new System.Drawing.Point(670, 214);
            this.lbl_FlowerName.Name = "lbl_FlowerName";
            this.lbl_FlowerName.Size = new System.Drawing.Size(75, 15);
            this.lbl_FlowerName.TabIndex = 108;
            this.lbl_FlowerName.Text = "-----------------";
            // 
            // las
            // 
            this.las.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.las.AutoSize = true;
            this.las.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.las.Location = new System.Drawing.Point(512, 252);
            this.las.Name = "las";
            this.las.Size = new System.Drawing.Size(46, 15);
            this.las.TabIndex = 107;
            this.las.Text = "Price:";
            // 
            // asd
            // 
            this.asd.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.asd.AutoSize = true;
            this.asd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.asd.Location = new System.Drawing.Point(512, 214);
            this.asd.Name = "asd";
            this.asd.Size = new System.Drawing.Size(125, 15);
            this.asd.TabIndex = 106;
            this.asd.Text = "Flower Arr. Name:";
            // 
            // picbox_FlowerImage
            // 
            this.picbox_FlowerImage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.picbox_FlowerImage.Location = new System.Drawing.Point(640, 76);
            this.picbox_FlowerImage.Name = "picbox_FlowerImage";
            this.picbox_FlowerImage.Size = new System.Drawing.Size(147, 108);
            this.picbox_FlowerImage.TabIndex = 105;
            this.picbox_FlowerImage.TabStop = false;
            // 
            // txt_search
            // 
            this.txt_search.AccessibleName = "";
            this.txt_search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.Location = new System.Drawing.Point(22, 76);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(172, 24);
            this.txt_search.TabIndex = 103;
            this.txt_search.Tag = "";
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // dgv_FlowerRecords
            // 
            this.dgv_FlowerRecords.AllowUserToAddRows = false;
            this.dgv_FlowerRecords.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_FlowerRecords.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_FlowerRecords.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_FlowerRecords.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_FlowerRecords.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_FlowerRecords.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_FlowerRecords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_FlowerRecords.Location = new System.Drawing.Point(22, 106);
            this.dgv_FlowerRecords.Name = "dgv_FlowerRecords";
            this.dgv_FlowerRecords.ReadOnly = true;
            this.dgv_FlowerRecords.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_FlowerRecords.RowHeadersVisible = false;
            this.dgv_FlowerRecords.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_FlowerRecords.Size = new System.Drawing.Size(471, 208);
            this.dgv_FlowerRecords.TabIndex = 167;
            this.dgv_FlowerRecords.DoubleClick += new System.EventHandler(this.dgv_FlowerRecords_DoubleClick);
            // 
            // btnSelect
            // 
            this.btnSelect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnSelect.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnSelect.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btnSelect.BorderRadius = 5;
            this.btnSelect.BorderSize = 0;
            this.btnSelect.FlatAppearance.BorderSize = 0;
            this.btnSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelect.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.ForeColor = System.Drawing.Color.White;
            this.btnSelect.Location = new System.Drawing.Point(423, 320);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(70, 30);
            this.btnSelect.TabIndex = 104;
            this.btnSelect.Text = "Select";
            this.btnSelect.TextColor = System.Drawing.Color.White;
            this.btnSelect.UseVisualStyleBackColor = false;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // SelectFlowerArrangement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.ClientSize = new System.Drawing.Size(836, 362);
            this.Controls.Add(this.dgv_FlowerRecords);
            this.Controls.Add(this.lbl_FlowerPrice);
            this.Controls.Add(this.lbl_FlowerName);
            this.Controls.Add(this.las);
            this.Controls.Add(this.asd);
            this.Controls.Add(this.picbox_FlowerImage);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.panel1);
            this.Name = "SelectFlowerArrangement";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SelectFlowerArrangement";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_FlowerImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_FlowerRecords)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_FlowerPrice;
        private System.Windows.Forms.Label lbl_FlowerName;
        private System.Windows.Forms.Label las;
        private System.Windows.Forms.Label asd;
        private System.Windows.Forms.PictureBox picbox_FlowerImage;
        private RoundedButton btnSelect;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.DataGridView dgv_FlowerRecords;
    }
}
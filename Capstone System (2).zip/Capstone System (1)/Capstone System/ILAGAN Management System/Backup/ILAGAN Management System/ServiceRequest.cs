﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ServiceRequest : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public ServiceRequest()
        {
            InitializeComponent();
            db = y.GetConnection();
            customizeDesign();
            LoadServiceRequests();
        }
        private void customizeDesign()
        {
            panelUserSubmenu.Visible = false;
            panelServiceSubMenu.Visible = false;
            panelTransactionSubMenu.Visible = false;
            panelInventorySubMenu.Visible = false;
            panelReportsSubMenu.Visible = false;
            panelSettingsSubMenu.Visible = false;
        }

        private void hideSubMenu()
        {
            //user
            if (panelUserSubmenu.Visible == true)
                panelUserSubmenu.Visible = false;
            //service
            if (panelServiceSubMenu.Visible == true)
                panelServiceSubMenu.Visible = false;
            //transaction
            if (panelTransactionSubMenu.Visible == true)
                panelTransactionSubMenu.Visible = false;
            //inventory
            if (panelInventorySubMenu.Visible == true)
                panelInventorySubMenu.Visible = false;
            //reports
            if (panelReportsSubMenu.Visible == true)
                panelReportsSubMenu.Visible = false;
            //setting
            if (panelSettingsSubMenu.Visible == true)
                panelSettingsSubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        //Home Nav
        private void btn_Home_Click(object sender, EventArgs e)
        {
            Home form2 = new Home();
            form2.Show();
            this.Hide();
        }

        //UserSubMenu
        private void btn_User_Click(object sender, EventArgs e)
        {
            showSubMenu(panelUserSubmenu);
        }
        //TheSubMenus
        private void btn_AddUser_Click(object sender, EventArgs e)
        {
            AddUser form1 = new AddUser();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_UserLog_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_Permission_Click(object sender, EventArgs e)
        {
            Permission form1 = new Permission();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }

        //ServiceSubMenu
        private void btn_Service_Click(object sender, EventArgs e)
        {
            showSubMenu(panelServiceSubMenu);
        }
        //TheSubMenus
        private void btn_AddClient_Click(object sender, EventArgs e)
        {
            AddClient form3 = new AddClient();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ServiceRequest_Click(object sender, EventArgs e)
        {
            ServiceRequest form3 = new ServiceRequest();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Package_Click(object sender, EventArgs e)
        {
            CreatePackage form2 = new CreatePackage();
            form2.Show();
            this.Hide();
            hideSubMenu();
        }


        //TransactionSubMenu
        private void btn_Transaction_Click(object sender, EventArgs e)
        {
            showSubMenu(panelTransactionSubMenu);
        }
        //TheSubMenus
        private void btn_Payment_Click(object sender, EventArgs e)
        {
            Payment form3 = new Payment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_InstallmentPayment_Click_1(object sender, EventArgs e)
        {
            InstallmentPayment form3 = new InstallmentPayment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        //InventorySubMenus
        private void btn_Inventory_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelInventorySubMenu);
        }
        private void btn_AddEquipment_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        //ReportsSubMenus
        private void btn_Reports_Click(object sender, EventArgs e)
        {
            showSubMenu(panelReportsSubMenu);
        }
        private void btn_ServiceHistory_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_AccountReceivable_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_EquipmentReleaseLog_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_Inventory_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_Sales_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_EquipmentNarrative_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        //SettingsSubMenus
        private void btn_Settings_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSettingsSubMenu);
        }
        private void btn_EmployeeList_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_AccountDetails_Click(object sender, EventArgs e)
        {
            AccountDetails form3 = new AccountDetails();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ChangePassword_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }



        private void btnNewUser_Click(object sender, EventArgs e)
        {
            CreateNewServiceRequestForm form3 = new CreateNewServiceRequestForm();
            form3.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //ask the user if they want to logout
            DialogResult respond = MessageBox.Show("Are you sure you want to log out?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If user clicks 'Yes', log out and go back to login form
            if (respond == DialogResult.Yes)
            {
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }
        private void LoadServiceRequests()
        {
            string query = @"SELECT sr.ServiceRequestID,sr.ClientName,sr.DeceasedFName,sr.DeceasedLName,sr.ServiceType,sr.TotalPrice,ss.StatusName AS ServiceStatus,
                                    sr.PackageName,sr.CasketName,sr.VehicleName,sr.FlowerArrangementName,sr.EmbalmingDays
                             FROM ServiceRequests sr
                             JOIN ServiceStatus ss ON sr.ServiceStatusID = ss.ServiceStatusID";

            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                // Assuming db is your SqlConnection object
                DataTable dt = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                try
                {
                    db.Open();
                    adapter.Fill(dt);
                    dgv_ServiceRequestRecords.DataSource = dt; // Bind to DataGridView

                    dgv_ServiceRequestRecords.Columns["Complete_Service"].Visible = true;
                    SetButtonColumnColor();

                    // Set column headers
                    dgv_ServiceRequestRecords.Columns["ServiceRequestID"].HeaderText = "Request ID";
                    dgv_ServiceRequestRecords.Columns["ClientName"].HeaderText = "Client";
                    dgv_ServiceRequestRecords.Columns["DeceasedFName"].HeaderText = "Deceased First Name";
                    dgv_ServiceRequestRecords.Columns["DeceasedLName"].HeaderText = "Deceased Last Name";
                    dgv_ServiceRequestRecords.Columns["ServiceType"].HeaderText = "Service Type";
                    dgv_ServiceRequestRecords.Columns["ServiceStatus"].HeaderText = "Status";
                    dgv_ServiceRequestRecords.Columns["PackageName"].HeaderText = "Package";
                    dgv_ServiceRequestRecords.Columns["CasketName"].HeaderText = "Casket";
                    dgv_ServiceRequestRecords.Columns["VehicleName"].HeaderText = "Vehicle";
                    dgv_ServiceRequestRecords.Columns["FlowerArrangementName"].HeaderText = "Flower Arrangement";
                    dgv_ServiceRequestRecords.Columns["EmbalmingDays"].HeaderText = "Embalming Days";
                    dgv_ServiceRequestRecords.Columns["TotalPrice"].HeaderText = "Total Price";
                    dgv_ServiceRequestRecords.Columns["ServiceStatus"].HeaderText = "Status";  
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading service requests: " + ex.Message);
                }
                finally
                {
                    db.Close();
                }
            }
        }
        private void SetButtonColumnColor()
        {
            dgv_ServiceRequestRecords.Columns["Complete_Service"].DefaultCellStyle.BackColor = Color.Crimson; // Change to your desired color
            dgv_ServiceRequestRecords.Columns["Complete_Service"].DefaultCellStyle.ForeColor = Color.White; 
        }
        private void dgv_ServiceRequestRecords_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgv_ServiceRequestRecords.Columns["Complete_Service"].Index && e.RowIndex >= 0)
            {
                btnComplete_Click(sender, e);
            }
        }
        private void btnComplete_Click(object sender, EventArgs e)
        {
            if (dgv_ServiceRequestRecords.SelectedRows.Count > 0)
            {
                var selectedRow = dgv_ServiceRequestRecords.SelectedRows[0];
                int serviceRequestID = Convert.ToInt32(selectedRow.Cells["ServiceRequestID"].Value);

                // Confirmation dialog
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to mark this service request as complete?", "Confirm Completion", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    using (SqlCommand cmd = new SqlCommand("UPDATE ServiceRequests SET ServiceStatusID = @ServiceStatusID  WHERE ServiceRequestID = @ServiceRequestID", db))
                    {
                        cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);
                        cmd.Parameters.AddWithValue("@ServiceStatusID", 3);

                        try
                        {
                            db.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Service request marked as complete.");
                            
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error completing service request: " + ex.Message);
                        }
                        finally
                        {
                            db.Close();
                            LoadServiceRequests(); 
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a service request to complete.");
            }
        }
        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtsearch.Text.Trim();

            // If the search text is empty, reload the pending payments
            if (string.IsNullOrEmpty(searchText))
            {
                LoadServiceRequests();
                return;
            }

            // SQL query to search service requests
            string query = @"SELECT sr.ServiceRequestID,sr.ClientName,sr.DeceasedFName,sr.DeceasedLName,sr.ServiceType,sr.TotalPrice,ss.StatusName AS ServiceStatus,
                                    sr.PackageName,sr.CasketName,sr.VehicleName,sr.FlowerArrangementName,sr.EmbalmingDays
                             FROM ServiceRequests sr
                             JOIN ServiceStatus ss ON sr.ServiceStatusID = ss.ServiceStatusID
                             AND (sr.ClientName LIKE @SearchText OR 
                                  sr.DeceasedFName LIKE @SearchText OR 
                                  sr.DeceasedLName LIKE @SearchText OR
                             CAST(sr.ServiceRequestID AS NVARCHAR) LIKE @SearchText)"; 

            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                // Add search text parameter
                cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();

                try
                {
                    db.Open();
                    adapter.Fill(dataTable);

                    // Bind results to DataGridView or handle empty results
                    if (dataTable.Rows.Count > 0)
                    {
                        dgv_ServiceRequestRecords.DataSource = dataTable;
                    }
                    else
                    {
                        MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgv_ServiceRequestRecords.DataSource = null; // Clear the DataGridView if no records found
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class Home_Service : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        private int clientID;
        private string clientName;

        public int ReservationID { get; private set; }

        public int ServiceTypeId { get; set; }
        public string SelectedServiceType { get; set; }

        public Home_Service(int clientId, string name, int reservationID)
        {
            InitializeComponent();
            db = y.GetConnection();
            this.clientID = clientId;
            this.clientName = name;
            if (reservationID != 0)
            {
                MessageBox.Show("Loading reservation details for ID: " + reservationID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.ReservationID = reservationID;
                LoadReservationDetails(this.ReservationID);
            }
        }
        //wont populate start date and end date
        private void LoadReservationDetails(int reservationId)
        {
            string query = @"SELECT cr.Location, cr.StartDate, cr.EndDate 
                             FROM ChapelReservation cr
                             WHERE cr.ReservationID = @ReservationID";


            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@ReservationID", reservationId);
                try
                {
                    db.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        txt_homelocation.Text = reader["Location"].ToString();
                        //error
                        dtp_StartDate.Value = reader.GetDateTime(reader.GetOrdinal("StartDate"));
                        dtp_EndDate.Value = reader.GetDateTime(reader.GetOrdinal("EndDate"));
                    }
                    else
                    {
                        MessageBox.Show("Reservation not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading reservation details: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_homelocation.Text))
            {
                MessageBox.Show("Please input a location.", "Location Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtp_StartDate.Value.Date < DateTime.Today)
            {
                MessageBox.Show("Start date cannot be in the past.", "Invalid Start Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtp_EndDate.Value.Date < dtp_StartDate.Value.Date)
            {
                MessageBox.Show("End date cannot be earlier than the start date.", "Invalid End Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtp_StartDate.Value.Date == dtp_EndDate.Value.Date)
            {
                MessageBox.Show("Start date cannot be the same as the end date.", "Invalid Dates", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtp_StartDate.Value.Date > DateTime.Today.AddYears(1))
            {
                MessageBox.Show("Reservations cannot be made more than one year in advance.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (ReservationID == 0) // Create new reservation
            {
                if (CheckForExistingReservations(dtp_StartDate.Value, dtp_EndDate.Value))
                {
                    MessageBox.Show("The selected dates conflict with an existing reservation.", "Conflict Detected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                var confirmResult = MessageBox.Show("Are you sure you want to save this home service reservation?",
                                                     "Confirm Save",
                                                     MessageBoxButtons.YesNo,
                                                     MessageBoxIcon.Question);
                if (confirmResult == DialogResult.Yes)
                {
                    SaveHomeReservation();
                }
            }
            else
            {
                var confirmResult = MessageBox.Show("Are you sure you want to update this chapel reservation?",
                                             "Confirm Update",
                                             MessageBoxButtons.YesNo,
                                             MessageBoxIcon.Question);
                if (confirmResult == DialogResult.Yes)
                {
                    UpdateChapelReservation();
                }
            }
        }
        //to insert database
        private void SaveHomeReservation()
        {
            string query = @"INSERT INTO ChapelReservation ( ClientID, ServiceTypeID, ReservationStatusID, ServiceTypeName, StartDate, EndDate, Location, ReservedBy)
                     VALUES (@ClientID, @ServiceTypeID, @ReservationStatusID, @ServiceTypeName, @StartDate, @EndDate, @Location, @ReservedBy);
                     SELECT SCOPE_IDENTITY();";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@ClientID", clientID);
                command.Parameters.AddWithValue("@ServiceTypeID", ServiceTypeId);
                command.Parameters.AddWithValue("@ReservationStatusID", 1);
                command.Parameters.AddWithValue("@ServiceTypeName", SelectedServiceType);
                command.Parameters.AddWithValue("@StartDate", dtp_StartDate.Value);
                command.Parameters.AddWithValue("@EndDate", dtp_EndDate.Value);
                command.Parameters.AddWithValue("@Location", txt_homelocation.Text);
                command.Parameters.AddWithValue("@ReservedBy", clientName);
                try
                {
                    db.Open();
                    ReservationID = Convert.ToInt32(command.ExecuteScalar()); // Get the inserted ReservationID
                    MessageBox.Show("Home service reservation saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving home service reservation: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
        //for update
        private void UpdateChapelReservation()
        {
            string query = @"UPDATE ChapelReservation SET Location = @Location,  ServiceTypeID = @ServiceTypeID, StartDate = @StartDate, EndDate = @EndDate, ReservedBy = @ReservedBy
                             WHERE ReservationID = @ReservationID";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@Location", txt_homelocation.Text);
                command.Parameters.AddWithValue("@ServiceTypeID", ServiceTypeId);
                command.Parameters.AddWithValue("@StartDate", dtp_StartDate.Value);
                command.Parameters.AddWithValue("@EndDate", dtp_EndDate.Value);
                command.Parameters.AddWithValue("@ReservedBy", clientName);
                command.Parameters.AddWithValue("@ReservationID", ReservationID);

                try
                {
                    db.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Chapel reservation updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating chapel reservation: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
        private bool CheckForExistingReservations(DateTime startDate, DateTime endDate)
        {
            string query = @"SELECT COUNT(*) FROM ChapelReservation 
                             WHERE 
                            ((StartDate <= @EndDate) AND (EndDate >= @StartDate))";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@StartDate", startDate);
                command.Parameters.AddWithValue("@EndDate", endDate);

                try
                {
                    db.Open();
                    int count = (int)command.ExecuteScalar();
                    return count > 0; // Return true if there are overlapping reservations
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error checking existing reservations: " + ex.Message);
                    return false; // Assume no conflict on error
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }

    }
}
